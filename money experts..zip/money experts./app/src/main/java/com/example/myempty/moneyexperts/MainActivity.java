package com.example.myempty.moneyexperts;


import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {

    // ======================= THEME COLORS (instance — light/dark) =======================
    private int COLOR_BG          = 0xFF000000;
    private int COLOR_CARD        = 0xFF121212;
    private int COLOR_CARD_2      = 0xFF171717;
    private int COLOR_BORDER      = 0xFF262626;
    private int COLOR_TEXT        = 0xFFFFFFFF;
    private int COLOR_TEXT_MUTED  = 0xFF9A9A9A;
    private int COLOR_INCOME      = 0xFF35D07F;
    private int COLOR_EXPENSE     = 0xFFFF5C5C;
    private int COLOR_ACCENT      = 0xFF35D07F;

    private static final int DARK_BG          = 0xFF000000;
    private static final int DARK_CARD        = 0xFF121212;
    private static final int DARK_CARD_2      = 0xFF171717;
    private static final int DARK_BORDER      = 0xFF262626;
    private static final int DARK_TEXT        = 0xFFFFFFFF;
    private static final int DARK_TEXT_MUTED  = 0xFF9A9A9A;

    private static final int LIGHT_BG         = 0xFFF5F6FA;
    private static final int LIGHT_CARD       = 0xFFFFFFFF;
    private static final int LIGHT_CARD_2     = 0xFFF0F1F5;
    private static final int LIGHT_BORDER     = 0xFFE0E2EA;
    private static final int LIGHT_TEXT       = 0xFF111318;
    private static final int LIGHT_TEXT_MUTED = 0xFF6B7180;

    // ======================= PREFS KEYS =======================
    private static final String PREFS_NAME     = "money_experts_prefs";
    private static final String KEY_TXNS       = "transactions_json";
    private static final String KEY_CURRENCY   = "currency_code";
    private static final String KEY_BUDGETS    = "budgets_json";
    private static final String KEY_GOALS      = "goals_json";
    private static final String KEY_DEBTS      = "debts_json";
    private static final String KEY_WALLETS    = "wallets_json";
    private static final String KEY_CATEGORIES = "categories_json";
    private static final String KEY_RECURRINGS = "recurrings_json";
    private static final String KEY_THEME      = "theme_mode"; // dark/light
    private static final String KEY_PIN_HASH   = "pin_hash";
    private static final String KEY_LOCK_ON    = "lock_enabled";
    private static final String KEY_BIOMETRIC  = "biometric_enabled";
    private static final String KEY_REMINDER_ON = "reminder_on";
    private static final String KEY_REMINDER_HOUR = "reminder_hour";
    private static final String KEY_REMINDER_MIN  = "reminder_min";

    // ======================= CONSTANTS =======================
    private static final String[] CURRENCY_CODES   = {"BDT", "USD", "INR", "EUR"};
    private static final String[] CURRENCY_SYMBOLS = {"৳", "$", "₹", "€"};
    private static final String[] CURRENCY_NAMES   = {
            "Bangladeshi Taka (৳)", "US Dollar ($)", "Indian Rupee (₹)", "Euro (€)"
    };

    private static final int[] CHART_COLORS = {
            0xFFFF5C5C, 0xFF35D07F, 0xFF5C9AFF, 0xFFFFD05C, 0xFFB05CFF,
            0xFFFF5CB0, 0xFF5CFFFF, 0xFFA0A0A0, 0xFFFF9A5C, 0xFF5CFFB0,
            0xFFFF7A5C, 0xFF7A5CFF
    };

    private static final String DEFAULT_INCOME_CATS = "Salary,Business,Investment,Gift,Other";
    private static final String DEFAULT_EXPENSE_CATS = "Food,Transport,Bills,Shopping,Health,Entertainment,Education,Rent,Other";

    private static final String NOTIF_CHANNEL_ID = "money_experts_channel";
    private static final int NOTIF_ID_DAILY = 1001;

    // ======================= STATE =======================
    private final List<Transaction> transactions = new ArrayList<>();
    private final List<Budget> budgets = new ArrayList<>();
    private final List<Goal> goals = new ArrayList<>();
    private final List<Debt> debts = new ArrayList<>();
    private final List<Wallet> wallets = new ArrayList<>();
    private final List<Recurring> recurrings = new ArrayList<>();
    private final List<String> incomeCategories = new ArrayList<>();
    private final List<String> expenseCategories = new ArrayList<>();
    private final Map<String, List<Double>> budgetSpentCache = new HashMap<>();

    private SharedPreferences prefs;
    private String currencySymbol = "৳";
    private String currencyCode = "BDT";
    private boolean isLightTheme = false;
    private boolean unlocked = false;

    private FrameLayout rootFrame;
    private FrameLayout contentHost;
    private LinearLayout navBar;

    private int currentTab = 0; // 0 home, 1 add, 2 chart, 3 profile

    // search filter
    private String filterQuery = "";
    private int filterType = 0; // 0 all, 1 income, -1 expense
    private String filterCategory = null;
    private String filterWallet = null;
    private long filterDateFrom = 0L;
    private long filterDateTo = 0L;

    // ======================= MODELS =======================
    private static class Transaction {
        String id;
        String description;
        double amount;
        boolean isIncome;
        String category;
        long timestamp;
        String note;
        String walletId = "cash";

        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("desc", description);
            o.put("amount", amount);
            o.put("income", isIncome);
            o.put("cat", category);
            o.put("ts", timestamp);
            o.put("note", note == null ? "" : note);
            o.put("wallet", walletId == null ? "cash" : walletId);
            return o;
        }

        static Transaction fromJson(JSONObject o) {
            Transaction t = new Transaction();
            t.id = o.optString("id", UUID.randomUUID().toString());
            t.description = o.optString("desc", "");
            t.amount = o.optDouble("amount", 0.0);
            t.isIncome = o.optBoolean("income", false);
            t.category = o.optString("cat", "Other");
            t.timestamp = o.optLong("ts", System.currentTimeMillis());
            t.note = o.optString("note", "");
            t.walletId = o.optString("wallet", "cash");
            return t;
        }
    }

    private static class Budget {
        String category; // "__total__" মানে মোট
        double limit;
        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("cat", category);
            o.put("limit", limit);
            return o;
        }
        static Budget fromJson(JSONObject o) {
            Budget b = new Budget();
            b.category = o.optString("cat", "Other");
            b.limit = o.optDouble("limit", 0);
            return b;
        }
    }

    private static class Goal {
        String id, name;
        double target, saved;
        long deadline;
        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("name", name);
            o.put("target", target); o.put("saved", saved);
            o.put("deadline", deadline);
            return o;
        }
        static Goal fromJson(JSONObject o) {
            Goal g = new Goal();
            g.id = o.optString("id", UUID.randomUUID().toString());
            g.name = o.optString("name", "Goal");
            g.target = o.optDouble("target", 0);
            g.saved = o.optDouble("saved", 0);
            g.deadline = o.optLong("deadline", 0);
            return g;
        }
    }

    private static class Debt {
        String id, person, note;
        double amount, paid;
        long date, dueDate;
        boolean iGave; // true = আমি দিয়েছি (পাবো), false = আমি নিয়েছি (দেবো)
        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("person", person); o.put("note", note == null ? "" : note);
            o.put("amount", amount); o.put("paid", paid);
            o.put("date", date); o.put("due", dueDate);
            o.put("iGave", iGave);
            return o;
        }
        static Debt fromJson(JSONObject o) {
            Debt d = new Debt();
            d.id = o.optString("id", UUID.randomUUID().toString());
            d.person = o.optString("person", "");
            d.note = o.optString("note", "");
            d.amount = o.optDouble("amount", 0);
            d.paid = o.optDouble("paid", 0);
            d.date = o.optLong("date", System.currentTimeMillis());
            d.dueDate = o.optLong("due", 0);
            d.iGave = o.optBoolean("iGave", true);
            return d;
        }
        double remaining() { return Math.max(0, amount - paid); }
        boolean isPaid() { return paid >= amount - 0.001; }
    }

    private static class Wallet {
        String id, name;
        double initial;
        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("name", name); o.put("init", initial);
            return o;
        }
        static Wallet fromJson(JSONObject o) {
            Wallet w = new Wallet();
            w.id = o.optString("id", UUID.randomUUID().toString());
            w.name = o.optString("name", "Wallet");
            w.initial = o.optDouble("init", 0);
            return w;
        }
    }

    private static class Recurring {
        String id, description, category, walletId;
        double amount;
        boolean isIncome;
        int interval; // 1=daily, 7=weekly, 30=monthly
        long lastRun;
        boolean active;
        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("desc", description);
            o.put("amount", amount); o.put("income", isIncome);
            o.put("cat", category); o.put("wallet", walletId);
            o.put("interval", interval); o.put("lastRun", lastRun);
            o.put("active", active);
            return o;
        }
        static Recurring fromJson(JSONObject o) {
            Recurring r = new Recurring();
            r.id = o.optString("id", UUID.randomUUID().toString());
            r.description = o.optString("desc", "");
            r.amount = o.optDouble("amount", 0);
            r.isIncome = o.optBoolean("income", false);
            r.category = o.optString("cat", "Other");
            r.walletId = o.optString("wallet", "cash");
            r.interval = o.optInt("interval", 30);
            r.lastRun = o.optLong("lastRun", 0);
            r.active = o.optBoolean("active", true);
            return r;
        }
    }

    // ======================= LIFECYCLE =======================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        currencyCode = prefs.getString(KEY_CURRENCY, "BDT");
        currencySymbol = symbolForCode(currencyCode);
        isLightTheme = "light".equals(prefs.getString(KEY_THEME, "dark"));
        applyTheme();

        loadCategories();
        loadWallets();
        loadTransactions();
        loadBudgets();
        loadGoals();
        loadDebts();
        loadRecurrings();
        processRecurrings(); // app open হলে missed recurring ট্রানজেকশন তৈরি

        // লক স্ক্রিন (PIN সেট থাকলে)
        if (prefs.getBoolean(KEY_LOCK_ON, false) && !prefs.getString(KEY_PIN_HASH, "").isEmpty()) {
            unlocked = false;
        } else {
            unlocked = true;
        }

        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(COLOR_BG);

        contentHost = new FrameLayout(this);
        FrameLayout.LayoutParams hostLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        rootFrame.addView(contentHost, hostLp);

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams navLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(78));
        navLp.gravity = Gravity.BOTTOM;
        navLp.setMargins(dp(18), 0, dp(18), dp(18));
        rootFrame.addView(navBar, navLp);

        setContentView(rootFrame);

        Window w = getWindow();
        w.setStatusBarColor(COLOR_BG);
        w.setNavigationBarColor(COLOR_BG);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        createNotificationChannel();
        if (prefs.getBoolean(KEY_REMINDER_ON, false)) {
            scheduleDailyReminder(prefs.getInt(KEY_REMINDER_HOUR, 20), prefs.getInt(KEY_REMINDER_MIN, 0));
        }

        if (!unlocked) {
            showLockScreen();
        } else {
            rebuildNavBar();
            showHome();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!unlocked) return;
        if (prefs.getBoolean(KEY_LOCK_ON, false) && !prefs.getString(KEY_PIN_HASH, "").isEmpty()) {
            // back থেকে ফিরলে আবার lock (একটা ছোট grace period ছাড়া)
            // এখানে সরলতা রাখতে সবসময় lock করছি শুধু রি-এন্ট্রিতে।
        }
    }

    @Override
    public void onBackPressed() {
        if (!unlocked) return;
        if (currentTab != 0) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    // ======================= THEME =======================
    private void applyTheme() {
        if (isLightTheme) {
            COLOR_BG = LIGHT_BG;
            COLOR_CARD = LIGHT_CARD;
            COLOR_CARD_2 = LIGHT_CARD_2;
            COLOR_BORDER = LIGHT_BORDER;
            COLOR_TEXT = LIGHT_TEXT;
            COLOR_TEXT_MUTED = LIGHT_TEXT_MUTED;
        } else {
            COLOR_BG = DARK_BG;
            COLOR_CARD = DARK_CARD;
            COLOR_CARD_2 = DARK_CARD_2;
            COLOR_BORDER = DARK_BORDER;
            COLOR_TEXT = DARK_TEXT;
            COLOR_TEXT_MUTED = DARK_TEXT_MUTED;
        }
        COLOR_INCOME = 0xFF35D07F;
        COLOR_EXPENSE = 0xFFFF5C5C;
        COLOR_ACCENT = 0xFF35D07F;
    }

    private void toggleTheme() {
        isLightTheme = !isLightTheme;
        prefs.edit().putString(KEY_THEME, isLightTheme ? "light" : "dark").apply();
        applyTheme();
        if (rootFrame != null) rootFrame.setBackgroundColor(COLOR_BG);
        Window w = getWindow();
        w.setStatusBarColor(COLOR_BG);
        w.setNavigationBarColor(COLOR_BG);
        rebuildNavBar();
        showProfile();
        toast(isLightTheme ? "Light theme enabled" : "Dark theme enabled");
    }

    // ======================= STORAGE / CATEGORIES / WALLETS =======================
    private void loadCategories() {
        incomeCategories.clear();
        expenseCategories.clear();
        String raw = prefs.getString(KEY_CATEGORIES, "");
        if (raw == null || raw.trim().isEmpty()) {
            for (String c : DEFAULT_INCOME_CATS.split(",")) incomeCategories.add(c);
            for (String c : DEFAULT_EXPENSE_CATS.split(",")) expenseCategories.add(c);
        } else {
            try {
                JSONObject o = new JSONObject(raw);
                JSONArray inc = o.optJSONArray("income");
                JSONArray exp = o.optJSONArray("expense");
                if (inc != null) for (int i = 0; i < inc.length(); i++) incomeCategories.add(inc.optString(i));
                if (exp != null) for (int i = 0; i < exp.length(); i++) expenseCategories.add(exp.optString(i));
            } catch (JSONException ignored) { }
        }
        if (incomeCategories.isEmpty()) for (String c : DEFAULT_INCOME_CATS.split(",")) incomeCategories.add(c);
        if (expenseCategories.isEmpty()) for (String c : DEFAULT_EXPENSE_CATS.split(",")) expenseCategories.add(c);
    }

    private void saveCategories() {
        try {
            JSONObject o = new JSONObject();
            JSONArray inc = new JSONArray(); for (String s : incomeCategories) inc.put(s);
            JSONArray exp = new JSONArray(); for (String s : expenseCategories) exp.put(s);
            o.put("income", inc); o.put("expense", exp);
            prefs.edit().putString(KEY_CATEGORIES, o.toString()).apply();
        } catch (JSONException ignored) { }
    }

    private void loadWallets() {
        wallets.clear();
        String raw = prefs.getString(KEY_WALLETS, "");
        if (raw == null || raw.trim().isEmpty()) {
            addDefaultWallet("cash", "Cash");
            addDefaultWallet("bank", "Bank");
            addDefaultWallet("bkash", "bKash");
            addDefaultWallet("nagad", "Nagad");
            saveWallets();
            return;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) wallets.add(Wallet.fromJson(o));
            }
        } catch (JSONException ignored) { }
        if (wallets.isEmpty()) {
            addDefaultWallet("cash", "Cash");
            addDefaultWallet("bank", "Bank");
            addDefaultWallet("bkash", "bKash");
            addDefaultWallet("nagad", "Nagad");
            saveWallets();
        }
    }

    private void addDefaultWallet(String id, String name) {
        Wallet w = new Wallet();
        w.id = id; w.name = name; w.initial = 0;
        wallets.add(w);
    }

    private void saveWallets() {
        JSONArray arr = new JSONArray();
        for (Wallet w : wallets) {
            try { arr.put(w.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_WALLETS, arr.toString()).apply();
    }

    private String walletNameById(String id) {
        for (Wallet w : wallets) if (w.id.equals(id)) return w.name;
        return "Cash";
    }

    private double walletBalance(String id) {
        double bal = 0;
        for (Wallet w : wallets) if (w.id.equals(id)) { bal = w.initial; break; }
        for (Transaction t : transactions) {
            if (!id.equals(t.walletId)) continue;
            bal += t.isIncome ? t.amount : -t.amount;
        }
        return bal;
    }

    private void loadTransactions() {
        transactions.clear();
        String raw = prefs.getString(KEY_TXNS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Transaction t = Transaction.fromJson(o);
                if (t.amount <= 0 || t.description == null || t.description.trim().isEmpty()) continue;
                if (t.walletId == null || t.walletId.isEmpty()) t.walletId = "cash";
                transactions.add(t);
            }
        } catch (JSONException e) {
            transactions.clear();
        }
    }

    private void saveTransactions() {
        JSONArray arr = new JSONArray();
        for (Transaction t : transactions) {
            try { arr.put(t.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_TXNS, arr.toString()).apply();
    }

    private void loadBudgets() {
        budgets.clear();
        String raw = prefs.getString(KEY_BUDGETS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) budgets.add(Budget.fromJson(o));
            }
        } catch (JSONException ignored) { }
    }

    private void saveBudgets() {
        JSONArray arr = new JSONArray();
        for (Budget b : budgets) {
            try { arr.put(b.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_BUDGETS, arr.toString()).apply();
    }

    private void loadGoals() {
        goals.clear();
        String raw = prefs.getString(KEY_GOALS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) goals.add(Goal.fromJson(o));
            }
        } catch (JSONException ignored) { }
    }

    private void saveGoals() {
        JSONArray arr = new JSONArray();
        for (Goal g : goals) {
            try { arr.put(g.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_GOALS, arr.toString()).apply();
    }

    private void loadDebts() {
        debts.clear();
        String raw = prefs.getString(KEY_DEBTS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) debts.add(Debt.fromJson(o));
            }
        } catch (JSONException ignored) { }
    }

    private void saveDebts() {
        JSONArray arr = new JSONArray();
        for (Debt d : debts) {
            try { arr.put(d.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_DEBTS, arr.toString()).apply();
    }

    private void loadRecurrings() {
        recurrings.clear();
        String raw = prefs.getString(KEY_RECURRINGS, "");
        if (raw == null || raw.trim().isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) recurrings.add(Recurring.fromJson(o));
            }
        } catch (JSONException ignored) { }
    }

    private void saveRecurrings() {
        JSONArray arr = new JSONArray();
        for (Recurring r : recurrings) {
            try { arr.put(r.toJson()); } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_RECURRINGS, arr.toString()).apply();
    }

    private void processRecurrings() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Recurring r : recurrings) {
            if (!r.active || r.amount <= 0) continue;
            long intervalMs = r.interval * 24L * 60L * 60L * 1000L;
            if (r.lastRun == 0) r.lastRun = now - intervalMs;
            while (r.lastRun + intervalMs <= now) {
                Transaction t = new Transaction();
                t.id = UUID.randomUUID().toString();
                t.description = r.description + " (Auto)";
                t.amount = r.amount;
                t.isIncome = r.isIncome;
                t.category = r.category;
                t.timestamp = r.lastRun + intervalMs;
                t.note = "Recurring";
                t.walletId = r.walletId == null ? "cash" : r.walletId;
                transactions.add(t);
                r.lastRun += intervalMs;
                changed = true;
            }
        }
        if (changed) { saveTransactions(); saveRecurrings(); }
    }

    // ======================= HELPERS =======================
    private double totalIncome() { double s = 0; for (Transaction t : transactions) if (t.isIncome) s += t.amount; return s; }
    private double totalExpense() { double s = 0; for (Transaction t : transactions) if (!t.isIncome) s += t.amount; return s; }
    private double balance() { return totalIncome() - totalExpense(); }

    private String symbolForCode(String code) {
        for (int i = 0; i < CURRENCY_CODES.length; i++) if (CURRENCY_CODES[i].equals(code)) return CURRENCY_SYMBOLS[i];
        return "৳";
    }

    private String money(double amount) {
        return currencySymbol + String.format(Locale.US, "%,.2f", amount);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void hideKeyboard() {
        try {
            View v = getCurrentFocus();
            if (v != null) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            }
        } catch (Exception ignored) { }
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    private String fmtDateTime(long ts) { return new SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.US).format(new Date(ts)); }

    private String shortDate(long ts) {
        Calendar now = Calendar.getInstance();
        Calendar then = Calendar.getInstance();
        then.setTimeInMillis(ts);
        boolean sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR);
        if (sameDay) return new SimpleDateFormat("hh:mm a", Locale.US).format(new Date(ts));
        return new SimpleDateFormat("dd MMM", Locale.US).format(new Date(ts));
    }

    private String trimTrailingZeros(double d) {
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.format(Locale.US, "%.2f", d);
    }

    private Calendar startOfDay(long ts) {
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(ts);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    private boolean isSameMonth(long ts, Calendar ref) {
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(ts);
        return c.get(Calendar.YEAR) == ref.get(Calendar.YEAR)
                && c.get(Calendar.MONTH) == ref.get(Calendar.MONTH);
    }

    // ======================= TAB / NAVIGATION =======================
    private void rebuildNavBar() {
        navBar.removeAllViews();

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{isLightTheme ? 0xFFF0F1F5 : 0xFF101010,
                           isLightTheme ? 0xFFE7E9EF : 0xFF0A0A0A});
        bg.setCornerRadius(dp(26));
        bg.setStroke(dp(1), COLOR_BORDER);
        navBar.setBackground(bg);
        navBar.setElevation(dp(12));
        navBar.setPadding(dp(10), dp(6), dp(10), dp(6));

        navBar.addView(makeNavButton(0, NavIcon.HOME), weightParams());

        FrameLayout centerWrap = new FrameLayout(this);
        centerWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        FrameLayout plus = new FrameLayout(this);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(dp(52), dp(52));
        plp.gravity = Gravity.CENTER;
        plus.setLayoutParams(plp);

        GradientDrawable plusBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{0xFF35D07F, 0xFF1FA05C});
        plusBg.setShape(GradientDrawable.OVAL);
        plusBg.setStroke(dp(1), 0x5535D07F);
        plus.setBackground(plusBg);
        plus.setElevation(dp(6));

        NavIconView plusIcon = new NavIconView(this, NavIcon.PLUS, Color.BLACK);
        plus.addView(plusIcon, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        plus.setOnClickListener(v -> openAddTransactionDialog());
        centerWrap.addView(plus);
        navBar.addView(centerWrap);

        navBar.addView(makeNavButton(2, NavIcon.CHART), weightParams());
        navBar.addView(makeNavButton(3, NavIcon.PROFILE), weightParams());
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
    }

    private View makeNavButton(int tabIndex, int iconType) {
        FrameLayout btn = new FrameLayout(this);
        btn.setLayoutParams(weightParams());
        int tint = (currentTab == tabIndex) ? COLOR_ACCENT : COLOR_TEXT_MUTED;
        NavIconView icon = new NavIconView(this, iconType, tint);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(28), dp(28));
        ilp.gravity = Gravity.CENTER;
        btn.addView(icon, ilp);

        btn.setOnClickListener(v -> {
            if (tabIndex == 0) showHome();
            else if (tabIndex == 2) showCharts();
            else if (tabIndex == 3) showProfile();
        });
        return btn;
    }

    private void setTab(int tab) { currentTab = tab; rebuildNavBar(); }

    // ======================= HOME SCREEN =======================
    private void showHome() {
        if (!unlocked) { showLockScreen(); return; }
        setTab(0);
        contentHost.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(96));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Money Experts");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout settingsBtn = new FrameLayout(this);
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        GradientDrawable sBg = new GradientDrawable();
        sBg.setColor(COLOR_CARD);
        sBg.setCornerRadius(dp(12));
        sBg.setStroke(dp(1), COLOR_BORDER);
        settingsBtn.setBackground(sBg);
        settingsBtn.setElevation(dp(2));
        NavIconView dots = new NavIconView(this, NavIcon.DOTS, COLOR_TEXT);
        settingsBtn.addView(dots, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        settingsBtn.setOnClickListener(v -> showProfile());
        header.addView(settingsBtn, sLp);

        col.addView(header);
        col.addView(spacer(dp(18)));

        LinearLayout balanceCard = makeCard();
        LinearLayout bInner = new LinearLayout(this);
        bInner.setOrientation(LinearLayout.VERTICAL);
        bInner.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView bLabel = mutedText("Total Balance");
        bInner.addView(bLabel);

        TextView bValue = new TextView(this);
        double bal = balance();
        bValue.setText(money(bal));
        bValue.setTextColor(bal < 0 ? COLOR_EXPENSE : COLOR_TEXT);
        bValue.setTextSize(30f);
        bValue.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        bValue.setPadding(0, dp(6), 0, 0);
        bInner.addView(bValue);

        LinearLayout ioRow = new LinearLayout(this);
        ioRow.setOrientation(LinearLayout.HORIZONTAL);
        ioRow.setPadding(0, dp(16), 0, 0);

        ioRow.addView(makeStatBlock("Income", money(totalIncome()), COLOR_INCOME), weightParams2());
        ioRow.addView(makeStatBlock("Expenses", money(totalExpense()), COLOR_EXPENSE), weightParams2());
        bInner.addView(ioRow);

        // today & month spend
        Calendar now = Calendar.getInstance();
        Calendar dayStart = startOfDay(now.getTimeInMillis());
        double todaySpend = 0, monthSpend = 0;
        for (Transaction t : transactions) {
            if (t.isIncome) continue;
            if (t.timestamp >= dayStart.getTimeInMillis()) todaySpend += t.amount;
            if (isSameMonth(t.timestamp, now)) monthSpend += t.amount;
        }
        LinearLayout tmRow = new LinearLayout(this);
        tmRow.setOrientation(LinearLayout.HORIZONTAL);
        tmRow.setPadding(0, dp(12), 0, 0);
        tmRow.addView(makeStatBlock("Today's Spend", money(todaySpend), COLOR_EXPENSE), weightParams2());
        tmRow.addView(makeStatBlock("This Month", money(monthSpend), COLOR_EXPENSE), weightParams2());
        bInner.addView(tmRow);

        balanceCard.addView(bInner);
        col.addView(balanceCard);

        col.addView(spacer(dp(12)));

        // ============== সার্চ/ফিল্টার বার ==============
        col.addView(buildSearchBar());
        col.addView(spacer(dp(12)));

        // filtered list
        List<Transaction> filtered = applyFilter();
        boolean filterActive = isFilterActive();
        double fInc = 0, fExp = 0;
        for (Transaction t : filtered) if (t.isIncome) fInc += t.amount; else fExp += t.amount;

        LinearLayout recHeader = new LinearLayout(this);
        recHeader.setOrientation(LinearLayout.HORIZONTAL);
        recHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView recTitle = new TextView(this);
        recTitle.setText(filterActive ? "Filtered Results" : "Recent Transactions");
        recTitle.setTextColor(COLOR_TEXT);
        recTitle.setTextSize(17f);
        recTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        recHeader.addView(recTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView count = new TextView(this);
        count.setText(String.valueOf(filtered.size()));
        count.setTextColor(COLOR_TEXT_MUTED);
        count.setTextSize(13f);
        recHeader.addView(count);
        col.addView(recHeader);

        if (filterActive) {
            TextView fSummary = mutedText("Income: " + money(fInc) + " · Expense: " + money(fExp));
            fSummary.setPadding(0, dp(6), 0, 0);
            col.addView(fSummary);
        }

        col.addView(spacer(dp(12)));

        if (filtered.isEmpty()) {
            col.addView(buildEmptyState());
        } else {
            filtered.sort((a, b) -> Long.compare(b.timestamp, a.timestamp));
            for (Transaction t : filtered) {
                col.addView(buildTransactionRow(t));
                col.addView(spacer(dp(10)));
            }
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildSearchBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), COLOR_BORDER);
        row.setBackground(bg);
        row.setPadding(dp(14), dp(4), dp(6), dp(4));

        EditText input = new EditText(this);
        input.setHint("Search description, category, note…");
        input.setText(filterQuery);
        input.setTextColor(COLOR_TEXT);
        input.setHintTextColor(COLOR_TEXT_MUTED);
        input.setTextSize(14f);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        row.addView(input, new LinearLayout.LayoutParams(0, dp(44), 1f));
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                filterQuery = s == null ? "" : s.toString();
                // delay rebuild
                input.postDelayed(() -> { if (currentTab == 0) showHome(); }, 300);
            }
        });

        TextView filterBtn = new TextView(this);
        filterBtn.setText("Filter");
        filterBtn.setTextColor(COLOR_ACCENT);
        filterBtn.setTextSize(13f);
        filterBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        filterBtn.setPadding(dp(12), dp(10), dp(12), dp(10));
        filterBtn.setOnClickListener(v -> showSearchFilterDialog());
        row.addView(filterBtn);

        return row;
    }

    private boolean isFilterActive() {
        return filterType != 0 || filterCategory != null || filterWallet != null
                || filterDateFrom > 0 || filterDateTo > 0;
    }

    private List<Transaction> applyFilter() {
        List<Transaction> out = new ArrayList<>();
        String q = filterQuery == null ? "" : filterQuery.trim().toLowerCase(Locale.ROOT);
        for (Transaction t : transactions) {
            if (!q.isEmpty()) {
                String d = t.description == null ? "" : t.description.toLowerCase(Locale.ROOT);
                String c = t.category == null ? "" : t.category.toLowerCase(Locale.ROOT);
                String n = t.note == null ? "" : t.note.toLowerCase(Locale.ROOT);
                if (!d.contains(q) && !c.contains(q) && !n.contains(q)) continue;
            }
            if (filterType == 1 && !t.isIncome) continue;
            if (filterType == -1 && t.isIncome) continue;
            if (filterCategory != null && !filterCategory.equals(t.category)) continue;
            if (filterWallet != null && !filterWallet.equals(t.walletId)) continue;
            if (filterDateFrom > 0 && t.timestamp < filterDateFrom) continue;
            if (filterDateTo > 0 && t.timestamp > filterDateTo) continue;
            out.add(t);
        }
        return out;
    }

    private void showSearchFilterDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));

        TextView title = new TextView(this);
        title.setText("Filters");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        TextView typeLbl = mutedText("Type"); typeLbl.setPadding(0,0,0,dp(6)); box.addView(typeLbl);
        final Spinner typeSpinner = new Spinner(this);
        ArrayAdapter<String> ta = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"All", "Income only", "Expense only"});
        ta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(ta);
        typeSpinner.setSelection(filterType == 1 ? 1 : filterType == -1 ? 2 : 0);
        box.addView(typeSpinner);
        box.addView(spacer(dp(10)));

        TextView catLbl = mutedText("Category"); catLbl.setPadding(0,0,0,dp(6)); box.addView(catLbl);
        final Spinner catSpinner = new Spinner(this);
        List<String> allCats = new ArrayList<>();
        allCats.add("(Any)");
        allCats.addAll(incomeCategories);
        for (String c : expenseCategories) if (!allCats.contains(c)) allCats.add(c);
        ArrayAdapter<String> ca = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, allCats);
        ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        catSpinner.setAdapter(ca);
        if (filterCategory != null) {
            int idx = allCats.indexOf(filterCategory);
            if (idx >= 0) catSpinner.setSelection(idx);
        }
        box.addView(catSpinner);
        box.addView(spacer(dp(10)));

        TextView wLbl = mutedText("Wallet"); wLbl.setPadding(0,0,0,dp(6)); box.addView(wLbl);
        final Spinner wSpinner = new Spinner(this);
        List<String> walletNames = new ArrayList<>();
        walletNames.add("(Any)");
        List<String> walletIds = new ArrayList<>();
        walletIds.add(null);
        for (Wallet w : wallets) { walletNames.add(w.name); walletIds.add(w.id); }
        ArrayAdapter<String> wa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, walletNames);
        wa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        wSpinner.setAdapter(wa);
        if (filterWallet != null) {
            int idx = walletIds.indexOf(filterWallet);
            if (idx >= 0) wSpinner.setSelection(idx);
        }
        box.addView(wSpinner);
        box.addView(spacer(dp(10)));

        TextView dateLbl = mutedText("Date Range"); dateLbl.setPadding(0,0,0,dp(6)); box.addView(dateLbl);
        final Spinner dateSpinner = new Spinner(this);
        ArrayAdapter<String> da = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"All time", "Today", "This Week", "This Month", "Custom"});
        da.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dateSpinner.setAdapter(da);
        box.addView(dateSpinner);
        box.addView(spacer(dp(10)));

        final long[] customFrom = {filterDateFrom};
        final long[] customTo = {filterDateTo};

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setNeutralButton("Clear", (d, w) -> {
            filterType = 0; filterCategory = null; filterWallet = null;
            filterDateFrom = 0; filterDateTo = 0; filterQuery = "";
            showHome();
        });
        b.setPositiveButton("Apply", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                int ti = typeSpinner.getSelectedItemPosition();
                filterType = ti == 1 ? 1 : (ti == 2 ? -1 : 0);

                int ci = catSpinner.getSelectedItemPosition();
                filterCategory = ci <= 0 ? null : allCats.get(ci);

                int wi = wSpinner.getSelectedItemPosition();
                filterWallet = wi <= 0 ? null : walletIds.get(wi);

                int di = dateSpinner.getSelectedItemPosition();
                filterDateFrom = 0; filterDateTo = 0;
                Calendar now = Calendar.getInstance();
                if (di == 1) {
                    filterDateFrom = startOfDay(now.getTimeInMillis()).getTimeInMillis();
                    filterDateTo = now.getTimeInMillis();
                } else if (di == 2) {
                    Calendar c = startOfDay(now.getTimeInMillis());
                    c.add(Calendar.DAY_OF_YEAR, -6);
                    filterDateFrom = c.getTimeInMillis();
                    filterDateTo = now.getTimeInMillis();
                } else if (di == 3) {
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.DAY_OF_MONTH, 1);
                    filterDateFrom = startOfDay(c.getTimeInMillis()).getTimeInMillis();
                    filterDateTo = now.getTimeInMillis();
                } else if (di == 4) {
                    filterDateFrom = customFrom[0];
                    filterDateTo = customTo[0];
                }
                dialog.dismiss();
                showHome();
            });
        });
        dialog.show();

        dateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (first) { first = false; return; }
                if (pos != 4) return;
                // custom range picker
                final Calendar from = Calendar.getInstance();
                new DatePickerDialog(MainActivity.this, (dp, y, m, d) -> {
                    from.set(y, m, d, 0, 0, 0);
                    customFrom[0] = from.getTimeInMillis();
                    final Calendar to = Calendar.getInstance();
                    new DatePickerDialog(MainActivity.this, (dp2, y2, m2, d2) -> {
                        to.set(y2, m2, d2, 23, 59, 59);
                        customTo[0] = to.getTimeInMillis();
                    }, to.get(Calendar.YEAR), to.get(Calendar.MONTH), to.get(Calendar.DAY_OF_MONTH)).show();
                }, from.get(Calendar.YEAR), from.get(Calendar.MONTH), from.get(Calendar.DAY_OF_MONTH)).show();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
    }

    private LinearLayout.LayoutParams weightParams2() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private View makeStatBlock(String label, String value, int valueColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(mutedText(label));
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(valueColor);
        v.setTextSize(16f);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        v.setPadding(0, dp(4), 0, 0);
        box.addView(v);
        return box;
    }

    private View buildEmptyState() {
        LinearLayout wrap = makeCard();
        wrap.setPadding(dp(24), dp(34), dp(24), dp(34));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER_HORIZONTAL);

        NavIconView ic = new NavIconView(this, NavIcon.WALLET, COLOR_TEXT_MUTED);
        inner.addView(ic, new LinearLayout.LayoutParams(dp(46), dp(46)));

        TextView t1 = new TextView(this);
        t1.setText("No transactions yet");
        t1.setTextColor(COLOR_TEXT);
        t1.setTextSize(16f);
        t1.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t1.setPadding(0, dp(14), 0, 0);
        inner.addView(t1);

        TextView t2 = mutedText("Tap the + button to add your first transaction.");
        t2.setGravity(Gravity.CENTER);
        t2.setPadding(0, dp(6), 0, 0);
        inner.addView(t2);

        wrap.addView(inner);
        return wrap;
    }

    private View buildTransactionRow(final Transaction t) {
        LinearLayout row = makeCard();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));

        FrameLayout bubble = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(t.isIncome ? 0xFF10261A : 0xFF261414);
        bBg.setCornerRadius(dp(14));
        bBg.setStroke(dp(1), t.isIncome ? 0x3535D07F : 0x35FF5C5C);
        bubble.setBackground(bBg);
        bubble.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));

        NavIconView arrowIc = new NavIconView(this,
                t.isIncome ? NavIcon.ARROW_DOWN : NavIcon.ARROW_UP,
                t.isIncome ? COLOR_INCOME : COLOR_EXPENSE);
        bubble.addView(arrowIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        row.addView(bubble);

        LinearLayout middle = new LinearLayout(this);
        middle.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mLp.setMargins(dp(14), 0, dp(8), 0);
        middle.setLayoutParams(mLp);

        TextView desc = new TextView(this);
        desc.setText(t.description);
        desc.setTextColor(COLOR_TEXT);
        desc.setTextSize(15f);
        desc.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        desc.setSingleLine(true);
        desc.setEllipsize(TextUtils.TruncateAt.END);
        middle.addView(desc);

        TextView meta = new TextView(this);
        meta.setText(t.category + " · " + walletNameById(t.walletId) + " · " + shortDate(t.timestamp));
        meta.setTextColor(COLOR_TEXT_MUTED);
        meta.setTextSize(12f);
        meta.setPadding(0, dp(3), 0, 0);
        middle.addView(meta);

        row.addView(middle);

        TextView amt = new TextView(this);
        amt.setText((t.isIncome ? "+" : "-") + money(t.amount));
        amt.setTextColor(t.isIncome ? COLOR_INCOME : COLOR_EXPENSE);
        amt.setTextSize(15f);
        amt.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        row.addView(amt);

        row.setOnClickListener(v -> showTransactionDetails(t));
        return row;
    }

    // ======================= CHARTS SCREEN =======================
    private void showCharts() {
        if (!unlocked) return;
        setTab(2);
        contentHost.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(96));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("Analytics & Charts");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        col.addView(title);
        col.addView(spacer(dp(18)));

        if (transactions.isEmpty()) {
            col.addView(buildEmptyState());
        } else {
            LinearLayout flowCard = makeCard();
            flowCard.setPadding(dp(18), dp(18), dp(18), dp(18));
            TextView flowTitle = new TextView(this);
            flowTitle.setText("Cash Flow");
            flowTitle.setTextColor(COLOR_TEXT);
            flowTitle.setTextSize(16f);
            flowTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            flowCard.addView(flowTitle);

            TextView flowDesc = mutedText("Total Income vs Total Expenses");
            flowDesc.setPadding(0, dp(4), 0, dp(16));
            flowCard.addView(flowDesc);

            double inc = totalIncome();
            double exp = totalExpense();
            double total = inc + exp;
            int incPercent = total > 0 ? (int) Math.round((inc / total) * 100) : 0;
            int expPercent = 100 - incPercent;

            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14)));
            GradientDrawable barBg = new GradientDrawable();
            barBg.setCornerRadius(dp(7));
            barBg.setColor(COLOR_CARD_2);
            bar.setBackground(barBg);

            if (inc > 0) {
                View incBar = new View(this);
                incBar.setBackgroundColor(COLOR_INCOME);
                bar.addView(incBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, (float) inc));
            }
            if (exp > 0) {
                View expBar = new View(this);
                expBar.setBackgroundColor(COLOR_EXPENSE);
                bar.addView(expBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, (float) exp));
            }
            flowCard.addView(bar);

            LinearLayout labelsRow = new LinearLayout(this);
            labelsRow.setOrientation(LinearLayout.HORIZONTAL);
            labelsRow.setPadding(0, dp(8), 0, 0);

            TextView incLbl = new TextView(this);
            incLbl.setText("Inflow: " + incPercent + "%");
            incLbl.setTextColor(COLOR_INCOME);
            incLbl.setTextSize(12f);
            labelsRow.addView(incLbl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView expLbl = new TextView(this);
            expLbl.setText("Outflow: " + expPercent + "%");
            expLbl.setTextColor(COLOR_EXPENSE);
            expLbl.setTextSize(12f);
            expLbl.setGravity(Gravity.END);
            labelsRow.addView(expLbl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            flowCard.addView(labelsRow);
            col.addView(flowCard);
            col.addView(spacer(dp(16)));

            LinearLayout donutCard = makeCard();
            donutCard.setOrientation(LinearLayout.VERTICAL);
            donutCard.setPadding(dp(18), dp(18), dp(18), dp(18));

            TextView donutTitle = new TextView(this);
            donutTitle.setText("Expense Breakdown");
            donutTitle.setTextColor(COLOR_TEXT);
            donutTitle.setTextSize(16f);
            donutTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            donutCard.addView(donutTitle);

            List<String> cats = new ArrayList<>();
            List<Double> vals = new ArrayList<>();
            for (Transaction t : transactions) {
                if (!t.isIncome) {
                    int idx = cats.indexOf(t.category);
                    if (idx >= 0) vals.set(idx, vals.get(idx) + t.amount);
                    else { cats.add(t.category); vals.add(t.amount); }
                }
            }

            if (cats.isEmpty()) {
                donutCard.addView(mutedText("No expense data available."));
            } else {
                DonutChartView chartView = new DonutChartView(this, cats, vals);
                LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
                chartLp.topMargin = dp(14);
                donutCard.addView(chartView, chartLp);

                LinearLayout legendWrap = new LinearLayout(this);
                legendWrap.setOrientation(LinearLayout.VERTICAL);
                legendWrap.setPadding(0, dp(16), 0, 0);

                for (int i = 0; i < cats.size(); i++) {
                    LinearLayout row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(0, dp(6), 0, dp(6));

                    View dot = new View(this);
                    GradientDrawable dg = new GradientDrawable();
                    dg.setShape(GradientDrawable.OVAL);
                    dg.setColor(CHART_COLORS[i % CHART_COLORS.length]);
                    dot.setBackground(dg);
                    row.addView(dot, new LinearLayout.LayoutParams(dp(10), dp(10)));

                    TextView cName = new TextView(this);
                    cName.setText(cats.get(i));
                    cName.setTextColor(COLOR_TEXT);
                    cName.setTextSize(13f);
                    cName.setPadding(dp(10), 0, 0, 0);
                    row.addView(cName, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                    TextView cAmt = new TextView(this);
                    cAmt.setText(money(vals.get(i)));
                    cAmt.setTextColor(COLOR_TEXT_MUTED);
                    cAmt.setTextSize(13f);
                    row.addView(cAmt);

                    legendWrap.addView(row);
                }
                donutCard.addView(legendWrap);
            }
            col.addView(donutCard);
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ======================= TRANSACTION DETAILS & FORM =======================
    private void showTransactionDetails(final Transaction t) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));

        TextView title = new TextView(this);
        title.setText(t.description);
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(20f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);

        TextView amount = new TextView(this);
        amount.setText((t.isIncome ? "+" : "-") + money(t.amount));
        amount.setTextColor(t.isIncome ? COLOR_INCOME : COLOR_EXPENSE);
        amount.setTextSize(24f);
        amount.setTypeface(Typeface.create("sans-serif-light", Typeface.BOLD));
        amount.setPadding(0, dp(6), 0, dp(14));
        box.addView(amount);

        box.addView(detailLine("Type", t.isIncome ? "Income" : "Expense"));
        box.addView(detailLine("Category", t.category));
        box.addView(detailLine("Wallet", walletNameById(t.walletId)));
        box.addView(detailLine("Date & Time", fmtDateTime(t.timestamp)));
        if (t.note != null && !t.note.trim().isEmpty()) {
            box.addView(detailLine("Note", t.note));
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Close", null);
        b.setNeutralButton("Delete", (d, w) -> confirmDelete(t));
        b.setPositiveButton("Edit", (d, w) -> openEditTransactionDialog(t));
        AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
        });
        dialog.show();
    }

    private View detailLine(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));

        row.addView(mutedText(label), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(COLOR_TEXT);
        v.setTextSize(14f);
        row.addView(v);
        return row;
    }

    private void confirmDelete(final Transaction t) {
        new AlertDialog.Builder(this)
                .setTitle("Delete transaction?")
                .setMessage("This action cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    transactions.remove(t);
                    saveTransactions();
                    toast("Transaction deleted");
                    if (currentTab == 0) showHome();
                    else if (currentTab == 2) showCharts();
                    else if (currentTab == 3) showProfile();
                }).show();
    }

    private void openAddTransactionDialog() {
        if (!unlocked) return;
        openTransactionForm(null);
    }

    private void openEditTransactionDialog(Transaction existing) {
        openTransactionForm(existing);
    }

    private void openTransactionForm(final Transaction existing) {
        final boolean editing = existing != null;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));

        TextView title = new TextView(this);
        title.setText(editing ? "Edit Transaction" : "New Transaction");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(19f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(14));
        box.addView(title);

        final boolean[] isIncome = { editing && existing.isIncome };
        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);

        final TextView incomeBtn = makeTypeChip("Income", true, isIncome[0]);
        final TextView expenseBtn = makeTypeChip("Expense", false, !isIncome[0]);
        LinearLayout.LayoutParams chipLp1 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        chipLp1.rightMargin = dp(6);
        LinearLayout.LayoutParams chipLp2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        chipLp2.leftMargin = dp(6);
        typeRow.addView(incomeBtn, chipLp1);
        typeRow.addView(expenseBtn, chipLp2);
        box.addView(typeRow);
        box.addView(spacer(dp(12)));

        final EditText descInput = makeInput("Description", editing ? existing.description : "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(descInput);
        box.addView(spacer(dp(10)));

        final EditText amountInput = makeInput("Amount (" + currencySymbol + ")",
                editing ? trimTrailingZeros(existing.amount) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amountInput);
        box.addView(spacer(dp(10)));

        // তারিখ ও সময় (নতুন)
        final long[] tsHolder = { editing ? existing.timestamp : System.currentTimeMillis() };
        TextView dateBtn = new TextView(this);
        dateBtn.setText("Date & Time: " + fmtDateTime(tsHolder[0]));
        dateBtn.setTextColor(COLOR_TEXT);
        dateBtn.setTextSize(14f);
        dateBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(COLOR_CARD_2);
        dbg.setCornerRadius(dp(12));
        dbg.setStroke(dp(1), COLOR_BORDER);
        dateBtn.setBackground(dbg);
        dateBtn.setOnClickListener(v -> openDateTimePicker(tsHolder[0], newTs -> {
            tsHolder[0] = newTs;
            dateBtn.setText("Date & Time: " + fmtDateTime(newTs));
        }));
        box.addView(dateBtn);
        box.addView(spacer(dp(10)));

        // Wallet spinner (নতুন)
        TextView wLbl = mutedText("Wallet");
        wLbl.setPadding(dp(2), 0, 0, dp(6));
        box.addView(wLbl);

        final Spinner walletSpinner = new Spinner(this);
        List<String> walletNames = new ArrayList<>();
        final List<String> walletIds = new ArrayList<>();
        for (Wallet w : wallets) { walletNames.add(w.name); walletIds.add(w.id); }
        ArrayAdapter<String> wa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, walletNames);
        wa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        walletSpinner.setAdapter(wa);
        String initialWallet = editing && existing.walletId != null ? existing.walletId : "cash";
        int idx = walletIds.indexOf(initialWallet);
        if (idx >= 0) walletSpinner.setSelection(idx);
        box.addView(walletSpinner);
        box.addView(spacer(dp(10)));

        TextView catLabel = mutedText("Category");
        catLabel.setPadding(dp(2), 0, 0, dp(6));
        box.addView(catLabel);

        final Spinner catSpinner = new Spinner(this);
        final String[] incomeCats = incomeCategories.toArray(new String[0]);
        final String[] expenseCats = expenseCategories.toArray(new String[0]);

        setCategories(catSpinner, isIncome[0] ? incomeCats : expenseCats);
        if (editing) {
            String[] src = existing.isIncome ? incomeCats : expenseCats;
            for (int i = 0; i < src.length; i++) {
                if (src[i].equals(existing.category)) {
                    catSpinner.setSelection(i);
                    break;
                }
            }
        }
        box.addView(catSpinner);
        box.addView(spacer(dp(10)));

        final EditText noteInput = makeInput("Note (optional)",
                editing && existing.note != null ? existing.note : "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(noteInput);

        incomeBtn.setOnClickListener(v -> {
            isIncome[0] = true;
            styleTypeChip(incomeBtn, true, true);
            styleTypeChip(expenseBtn, false, false);
            setCategories(catSpinner, incomeCats);
        });
        expenseBtn.setOnClickListener(v -> {
            isIncome[0] = false;
            styleTypeChip(expenseBtn, false, true);
            styleTypeChip(incomeBtn, true, false);
            setCategories(catSpinner, expenseCats);
        });

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton(editing ? "Save" : "Add", null);

        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());

            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setTextColor(COLOR_ACCENT);
            positive.setOnClickListener(v -> {
                String desc = descInput.getText().toString().trim();
                String amtStr = amountInput.getText().toString().trim();
                String note = noteInput.getText().toString().trim();
                Object selCat = catSpinner.getSelectedItem();
                String category = selCat == null ? "Other" : selCat.toString();
                int wIdx = walletSpinner.getSelectedItemPosition();
                String walletId = wIdx >= 0 && wIdx < walletIds.size() ? walletIds.get(wIdx) : "cash";

                if (desc.isEmpty()) { toast("Enter a description"); return; }
                if (amtStr.isEmpty()) { toast("Enter an amount"); return; }
                double amount;
                try { amount = Double.parseDouble(amtStr); }
                catch (NumberFormatException e) { toast("Invalid amount"); return; }
                if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0) {
                    toast("Amount must be greater than zero"); return;
                }

                if (editing) {
                    existing.description = desc;
                    existing.amount = amount;
                    existing.isIncome = isIncome[0];
                    existing.category = category;
                    existing.note = note;
                    existing.timestamp = tsHolder[0];
                    existing.walletId = walletId;
                } else {
                    Transaction t = new Transaction();
                    t.id = UUID.randomUUID().toString();
                    t.description = desc;
                    t.amount = amount;
                    t.isIncome = isIncome[0];
                    t.category = category;
                    t.timestamp = tsHolder[0];
                    t.note = note;
                    t.walletId = walletId;
                    transactions.add(t);
                }

                saveTransactions();
                hideKeyboard();
                dialog.dismiss();
                toast(editing ? "Transaction updated" : "Transaction added");

                // বাজেট চেক (নতুন)
                if (!isIncome[0]) checkBudgetWarning(category);

                if (currentTab == 0) showHome();
                else if (currentTab == 2) showCharts();
                else if (currentTab == 3) showProfile();
            });
        });
        dialog.show();
    }

    private interface DateCallback { void onPicked(long ts); }

    private void openDateTimePicker(long initialTs, final DateCallback cb) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(initialTs);
        DatePickerDialog dpd = new DatePickerDialog(this, (view, year, month, day) -> {
            final Calendar innerCalendar = Calendar.getInstance();
            innerCalendar.set(year, month, day,
                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
            TimePickerDialog tpd = new TimePickerDialog(this, (tv, h, m) -> {
                innerCalendar.set(Calendar.HOUR_OF_DAY, h);
                innerCalendar.set(Calendar.MINUTE, m);
                cb.onPicked(innerCalendar.getTimeInMillis());
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false);
            tpd.show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dpd.show();
    }

    private void setCategories(Spinner spinner, String[] cats) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cats);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(a);
    }

    private TextView makeTypeChip(String label, boolean income, boolean active) {
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setGravity(Gravity.CENTER);
        chip.setTextSize(14f);
        chip.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        styleTypeChip(chip, income, active);
        return chip;
    }

    private void styleTypeChip(TextView chip, boolean income, boolean active) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (active) {
            bg.setColor(income ? 0xFF10261A : 0xFF261414);
            bg.setStroke(dp(1), income ? COLOR_INCOME : COLOR_EXPENSE);
            chip.setTextColor(income ? COLOR_INCOME : COLOR_EXPENSE);
        } else {
            bg.setColor(COLOR_CARD_2);
            bg.setStroke(dp(1), COLOR_BORDER);
            chip.setTextColor(COLOR_TEXT_MUTED);
        }
        chip.setBackground(bg);
    }

    private EditText makeInput(String hint, String initial, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(initial);
        e.setInputType(inputType);
        e.setTextColor(COLOR_TEXT);
        e.setHintTextColor(COLOR_TEXT_MUTED);
        e.setTextSize(15f);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setSingleLine(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD_2);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), COLOR_BORDER);
        e.setBackground(bg);
        return e;
    }

    // ======================= PROFILE & ABOUT =======================
    private void showProfile() {
        if (!unlocked) { showLockScreen(); return; }
        setTab(3);
        contentHost.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(96));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(24), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Profile & Settings");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView aboutBtn = new TextView(this);
        aboutBtn.setText("About");
        aboutBtn.setTextColor(COLOR_TEXT);
        aboutBtn.setTextSize(14f);
        aboutBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        aboutBtn.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable glassBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                isLightTheme ? new int[]{0x22000000, 0x11000000} : new int[]{0x33FFFFFF, 0x11FFFFFF});
        glassBg.setCornerRadius(dp(20));
        glassBg.setStroke(dp(1), isLightTheme ? 0x33000000 : 0x66FFFFFF);
        aboutBtn.setBackground(glassBg);
        aboutBtn.setOnClickListener(v -> showAboutDialog());
        LinearLayout.LayoutParams abLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        abLp.rightMargin = dp(12);
        header.addView(aboutBtn, abLp);

        FrameLayout backBtn = new FrameLayout(this);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD);
        bBg.setCornerRadius(dp(12));
        bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showHome());
        header.addView(backBtn, bLp);

        col.addView(header);
        col.addView(spacer(dp(20)));

        // App info
        LinearLayout infoCard = makeCard();
        LinearLayout infoInner = new LinearLayout(this);
        infoInner.setOrientation(LinearLayout.VERTICAL);
        infoInner.setPadding(dp(18), dp(18), dp(18), dp(18));

        FrameLayout avatar = new FrameLayout(this);
        GradientDrawable avBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{0xFF1FA05C, 0xFF35D07F});
        avBg.setShape(GradientDrawable.OVAL);
        avatar.setBackground(avBg);
        avatar.setLayoutParams(new LinearLayout.LayoutParams(dp(64), dp(64)));
        NavIconView personIc = new NavIconView(this, NavIcon.PROFILE_FILLED, Color.BLACK);
        avatar.addView(personIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        infoInner.addView(avatar);

        TextView appName = new TextView(this);
        appName.setText("Money Experts");
        appName.setTextColor(COLOR_TEXT);
        appName.setTextSize(18f);
        appName.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        appName.setPadding(0, dp(12), 0, 0);
        infoInner.addView(appName);

        TextView ver = mutedText("Version 1.1.0 · Personal Finance");
        ver.setPadding(0, dp(4), 0, 0);
        infoInner.addView(ver);

        infoCard.addView(infoInner);
        col.addView(infoCard);
        col.addView(spacer(dp(16)));

        // Currency
        LinearLayout curCard = makeCard();
        LinearLayout curInner = new LinearLayout(this);
        curInner.setOrientation(LinearLayout.VERTICAL);
        curInner.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView curTitle = new TextView(this);
        curTitle.setText("Currency");
        curTitle.setTextColor(COLOR_TEXT);
        curTitle.setTextSize(16f);
        curTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        curInner.addView(curTitle);

        TextView curDesc = mutedText("Changing currency updates display symbols only. Amounts stay the same.");
        curDesc.setPadding(0, dp(4), 0, dp(12));
        curInner.addView(curDesc);

        final Spinner curSpinner = new Spinner(this);
        ArrayAdapter<String> curAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, CURRENCY_NAMES);
        curAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        curSpinner.setAdapter(curAdapter);
        int selected = 0;
        for (int i = 0; i < CURRENCY_CODES.length; i++) {
            if (CURRENCY_CODES[i].equals(currencyCode)) { selected = i; break; }
        }
        curSpinner.setSelection(selected);
        curSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            @Override public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (first) { first = false; return; }
                currencyCode = CURRENCY_CODES[pos];
                currencySymbol = CURRENCY_SYMBOLS[pos];
                prefs.edit().putString(KEY_CURRENCY, currencyCode).apply();
                toast("Currency set to " + currencySymbol);
                showProfile();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        curInner.addView(curSpinner);
        curCard.addView(curInner);
        col.addView(curCard);
        col.addView(spacer(dp(16)));

        // Data storage
        LinearLayout dataCard = makeCard();
        LinearLayout dataInner = new LinearLayout(this);
        dataInner.setOrientation(LinearLayout.VERTICAL);
        dataInner.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView dTitle = new TextView(this);
        dTitle.setText("Data Storage");
        dTitle.setTextColor(COLOR_TEXT);
        dTitle.setTextSize(16f);
        dTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        dataInner.addView(dTitle);

        dataInner.addView(detailLine("Storage", "Offline · SharedPreferences"));
        dataInner.addView(detailLine("Transactions", String.valueOf(transactions.size())));
        dataInner.addView(detailLine("Total Income", money(totalIncome())));
        dataInner.addView(detailLine("Total Expenses", money(totalExpense())));

        dataCard.addView(dataInner);
        col.addView(dataCard);
        col.addView(spacer(dp(16)));

        // ==================== নতুন কার্ডগুলো ====================

        // বাজেট
        col.addView(buildProfileRow("Monthly Budget", "Set spending limits per category",
                () -> showBudgetScreen()));
        col.addView(spacer(dp(10)));
        // সেভিংস গোল
        col.addView(buildProfileRow("Savings Goals", "Save toward a target amount",
                () -> showGoalsScreen()));
        col.addView(spacer(dp(10)));
        // ধার/দেনা
        col.addView(buildProfileRow("Debts & Loans", "Track money you owe or are owed",
                () -> showDebtsScreen()));
        col.addView(spacer(dp(10)));
        // রিপোর্ট
        col.addView(buildProfileRow("Monthly Reports", "Detailed month-by-month analysis",
                () -> showReportsScreen()));
        col.addView(spacer(dp(10)));
        // রিকারিং
        col.addView(buildProfileRow("Recurring Transactions", "Auto-add salary, rent, bills",
                () -> showRecurringList()));
        col.addView(spacer(dp(10)));
        // ক্যাটেগরি ম্যানেজার
        col.addView(buildProfileRow("Manage Categories", "Add, rename, delete categories",
                () -> showCategoryManager()));
        col.addView(spacer(dp(10)));
        // ওয়ালেট
        col.addView(buildProfileRow("Wallets", "Manage multiple wallets & transfers",
                () -> showWalletsScreen()));
        col.addView(spacer(dp(10)));
        // ব্যাকআপ
        col.addView(buildProfileRow("Backup & Restore", "Export or import JSON / CSV",
                () -> showBackupScreen()));
        col.addView(spacer(dp(10)));
        // সিকিউরিটি
        col.addView(buildProfileRow("App Lock & Security", "PIN / biometric protection",
                () -> showSecurityScreen()));
        col.addView(spacer(dp(10)));
        // রিমাইন্ডার
        col.addView(buildProfileRow("Reminders", "Daily log reminder notification",
                () -> showReminderSettings()));
        col.addView(spacer(dp(10)));
        // থিম
        col.addView(buildProfileRow("Theme", isLightTheme ? "Light (tap to switch)" : "Dark (tap to switch)",
                () -> toggleTheme()));
        col.addView(spacer(dp(16)));

        // Danger zone
        LinearLayout dangerCard = makeCard();
        dangerCard.setBackground(dangerCardBg());
        LinearLayout dangerInner = new LinearLayout(this);
        dangerInner.setOrientation(LinearLayout.VERTICAL);
        dangerInner.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView dTitle2 = new TextView(this);
        dTitle2.setText("Danger Zone");
        dTitle2.setTextColor(COLOR_EXPENSE);
        dTitle2.setTextSize(16f);
        dTitle2.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        dangerInner.addView(dTitle2);

        TextView dDesc = mutedText("Delete all transactions stored on this device. This cannot be undone.");
        dDesc.setPadding(0, dp(6), 0, dp(12));
        dangerInner.addView(dDesc);

        TextView deleteAll = new TextView(this);
        deleteAll.setText("Delete All Transactions");
        deleteAll.setGravity(Gravity.CENTER);
        deleteAll.setTextColor(COLOR_EXPENSE);
        deleteAll.setTextSize(15f);
        deleteAll.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        deleteAll.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable delBg = new GradientDrawable();
        delBg.setColor(0x1AFF5C5C);
        delBg.setCornerRadius(dp(12));
        delBg.setStroke(dp(1), 0x66FF5C5C);
        deleteAll.setBackground(delBg);
        deleteAll.setOnClickListener(v -> confirmDeleteAll());
        dangerInner.addView(deleteAll);

        dangerCard.addView(dangerInner);
        col.addView(dangerCard);

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildProfileRow(String title, String subtitle, Runnable onClick) {
        LinearLayout row = makeCard();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(COLOR_TEXT);
        t.setTextSize(15f);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        texts.addView(t);

        TextView s = mutedText(subtitle);
        s.setTextSize(12f);
        s.setPadding(0, dp(3), 0, 0);
        texts.addView(s);

        row.addView(texts);

        TextView arrow = new TextView(this);
        arrow.setText("→");
        arrow.setTextColor(COLOR_ACCENT);
        arrow.setTextSize(18f);
        row.addView(arrow);

        row.setOnClickListener(v -> onClick.run());
        return row;
    }

    private void showAboutDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(10));

        TextView title = new TextView(this);
        title.setText("About Money Experts");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(20f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);

        TextView desc = mutedText("A premium, offline-first personal finance tracker. Keep your money management simple, dark, and private.");
        desc.setPadding(0, dp(8), 0, dp(20));
        box.addView(desc);

        box.addView(makeLinkRow("TikTok", "Pixel Craft BD", "https://www.tiktok.com/@pixelcraftbdofficial?"));
        box.addView(spacer(dp(8)));
        box.addView(makeLinkRow("YouTube", "World Mystery Zone", "https://youtube.com/@worldmysteryzone2.3?si=4AYxbFjmk2IEHt0_"));
        box.addView(spacer(dp(8)));
        box.addView(makeLinkRow("Telegram", "Daily Expense", "https://t.me/DailyExpenseg"));
        box.addView(spacer(dp(16)));

        TextView donateTitle = new TextView(this);
        donateTitle.setText("Support Development (Donate)");
        donateTitle.setTextColor(COLOR_ACCENT);
        donateTitle.setTextSize(15f);
        donateTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(donateTitle);

        TextView donateSub = mutedText("Binance USDT (BEP20):");
        donateSub.setPadding(0, dp(8), 0, dp(6));
        box.addView(donateSub);

        final String donateAddress = "0x34e2b5bae5f5a9ba6c3b99dfaaec2702a53a926a";
        TextView addressBox = new TextView(this);
        addressBox.setText(donateAddress);
        addressBox.setTextColor(COLOR_TEXT);
        addressBox.setTextSize(12f);
        addressBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD_2);
        abg.setCornerRadius(dp(8));
        abg.setStroke(dp(1), COLOR_BORDER);
        addressBox.setBackground(abg);
        addressBox.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Binance Address", donateAddress);
            if (clipboard != null) {
                clipboard.setPrimaryClip(clip);
                toast("Donate address copied to clipboard");
            }
        });
        box.addView(addressBox);

        TextView copyHint = mutedText("Tap the address above to copy");
        copyHint.setTextSize(11f);
        copyHint.setPadding(0, dp(4), 0, 0);
        box.addView(copyHint);

        scroll.addView(box);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(scroll);
        b.setNegativeButton("Close", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
        });
        dialog.show();
    }

    private View makeLinkRow(String platform, String handle, final String url) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD_2);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), COLOR_BORDER);
        row.setBackground(bg);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView pName = new TextView(this);
        pName.setText(platform);
        pName.setTextColor(COLOR_TEXT);
        pName.setTextSize(14f);
        pName.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        texts.addView(pName);

        TextView hName = new TextView(this);
        hName.setText(handle);
        hName.setTextColor(COLOR_TEXT_MUTED);
        hName.setTextSize(12f);
        texts.addView(hName);
        row.addView(texts);

        TextView arrow = new TextView(this);
        arrow.setText("→");
        arrow.setTextColor(COLOR_ACCENT);
        arrow.setTextSize(18f);
        row.addView(arrow);

        row.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            } catch (Exception e) {
                toast("Could not open link");
            }
        });
        return row;
    }

    private void confirmDeleteAll() {
        new AlertDialog.Builder(this)
                .setTitle("Delete all transactions?")
                .setMessage("All transaction records will be permanently removed from this device.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete All", (d, w) -> {
                    transactions.clear();
                    saveTransactions();
                    toast("All transactions deleted");
                    showProfile();
                }).show();
    }

    // ======================= BUDGET =======================
    private void checkBudgetWarning(String category) {
        Calendar now = Calendar.getInstance();
        double spent = 0;
        for (Transaction t : transactions) {
            if (t.isIncome) continue;
            if (!category.equals(t.category)) continue;
            if (isSameMonth(t.timestamp, now)) spent += t.amount;
        }
        Double catLimit = null;
        Double totalLimit = null;
        for (Budget b : budgets) {
            if (b.category.equals(category)) catLimit = b.limit;
            if ("__total__".equals(b.category)) totalLimit = b.limit;
        }
        double totalSpent = 0;
        for (Transaction t : transactions) {
            if (!t.isIncome && isSameMonth(t.timestamp, now)) totalSpent += t.amount;
        }
        if (catLimit != null && catLimit > 0) {
            double pct = spent / catLimit;
            if (pct >= 1.0) toast("⚠️ Budget exceeded for " + category + " (" + money(spent) + "/" + money(catLimit) + ")");
            else if (pct >= 0.8) toast("⚠️ 80% of " + category + " budget used");
        }
        if (totalLimit != null && totalLimit > 0) {
            double pct = totalSpent / totalLimit;
            if (pct >= 1.0) toast("⚠️ Monthly budget exceeded (" + money(totalSpent) + "/" + money(totalLimit) + ")");
            else if (pct >= 0.8) toast("⚠️ 80% of monthly budget used");
        }
    }

    private void showBudgetScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Monthly Budget");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        Calendar now = Calendar.getInstance();
        String monthName = new SimpleDateFormat("MMMM yyyy", Locale.US).format(now.getTime());

        TextView sub = mutedText("Budget for " + monthName);
        col.addView(sub);
        col.addView(spacer(dp(12)));

        double totalSpent = 0;
        for (Transaction t : transactions) if (!t.isIncome && isSameMonth(t.timestamp, now)) totalSpent += t.amount;

        // মোট বাজেট
        Double totalLimit = null;
        for (Budget b : budgets) if ("__total__".equals(b.category)) totalLimit = b.limit;

        LinearLayout totalCard = makeCard();
        totalCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView totT = new TextView(this);
        totT.setText("Total Monthly Budget");
        totT.setTextColor(COLOR_TEXT);
        totT.setTextSize(15f);
        totT.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        totalCard.addView(totT);

        if (totalLimit != null) {
            totalCard.addView(buildBudgetProgress(totalSpent, totalLimit, "Total"));
        } else {
            totalCard.addView(mutedText("No total budget set."));
        }
        final String cat = "__total__";
        final Double curLimit = totalLimit;
        TextView setTotal = new TextView(this);
        setTotal.setText(totalLimit == null ? "Set Total Budget" : "Edit Total Budget");
        setTotal.setTextColor(COLOR_ACCENT);
        setTotal.setTextSize(14f);
        setTotal.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        setTotal.setPadding(0, dp(12), 0, 0);
        setTotal.setOnClickListener(v -> showBudgetEditDialog(cat, curLimit == null ? 0 : curLimit));
        totalCard.addView(setTotal);
        col.addView(totalCard);
        col.addView(spacer(dp(12)));

        // প্রতি ক্যাটেগরি
        TextView perLbl = mutedText("Per-category budgets");
        perLbl.setPadding(0, 0, 0, dp(8));
        col.addView(perLbl);

        for (String cat2 : expenseCategories) {
            Double limit = null;
            for (Budget b : budgets) if (b.category.equals(cat2)) limit = b.limit;
            double spent = 0;
            for (Transaction t : transactions) {
                if (!t.isIncome && cat2.equals(t.category) && isSameMonth(t.timestamp, now)) spent += t.amount;
            }
            LinearLayout c = makeCard();
            c.setPadding(dp(18), dp(16), dp(18), dp(16));
            TextView ct = new TextView(this);
            ct.setText(cat2);
            ct.setTextColor(COLOR_TEXT);
            ct.setTextSize(15f);
            ct.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            c.addView(ct);
            if (limit != null && limit > 0) {
                c.addView(buildBudgetProgress(spent, limit, cat2));
            } else {
                c.addView(mutedText("No limit · spent " + money(spent)));
            }
            final String finalCat = cat2;
            final Double fl = limit;
            TextView editBtn = new TextView(this);
            editBtn.setText(limit == null ? "Set limit" : "Edit limit");
            editBtn.setTextColor(COLOR_ACCENT);
            editBtn.setTextSize(13f);
            editBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            editBtn.setPadding(0, dp(10), 0, 0);
            editBtn.setOnClickListener(v -> showBudgetEditDialog(finalCat, fl == null ? 0 : fl));
            c.addView(editBtn);
            col.addView(c);
            col.addView(spacer(dp(10)));
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildBudgetProgress(double spent, double limit, String label) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(10), 0, 0);

        double pct = limit > 0 ? spent / limit : 0;
        int color = pct >= 1.0 ? COLOR_EXPENSE : (pct >= 0.8 ? 0xFFFFC107 : COLOR_INCOME);

        LinearLayout bar = new LinearLayout(this);
        bar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(5)); bg.setColor(COLOR_CARD_2);
        bar.setBackground(bg);

        float filled = (float) Math.min(1.0, pct);
        View fill = new View(this);
        fill.setBackgroundColor(color);
        bar.addView(fill, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, filled));
        View empty = new View(this);
        bar.addView(empty, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, Math.max(0.001f, 1f - filled)));
        wrap.addView(bar);

        TextView info = new TextView(this);
        info.setText(money(spent) + " / " + money(limit)
                + " (" + (int) Math.round(pct * 100) + "%)"
                + (pct > 1.0 ? " · Over by " + money(spent - limit) : " · Remaining " + money(limit - spent)));
        info.setTextColor(pct >= 1.0 ? COLOR_EXPENSE : (pct >= 0.8 ? 0xFFFFC107 : COLOR_TEXT_MUTED));
        info.setTextSize(12f);
        info.setPadding(0, dp(6), 0, 0);
        wrap.addView(info);
        return wrap;
    }

    private void showBudgetEditDialog(final String category, double currentLimit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("Budget: " + ("__total__".equals(category) ? "Total" : category));
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(17f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final EditText amount = makeInput("Limit (" + currencySymbol + ")",
                currentLimit > 0 ? trimTrailingZeros(currentLimit) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amount);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setNeutralButton("Remove", (d, w) -> {
            for (int i = budgets.size() - 1; i >= 0; i--) {
                if (budgets.get(i).category.equals(category)) budgets.remove(i);
            }
            saveBudgets();
            showBudgetScreen();
        });
        b.setPositiveButton("Save", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String s = amount.getText().toString().trim();
                if (s.isEmpty()) { toast("Enter a limit"); return; }
                double lim;
                try { lim = Double.parseDouble(s); } catch (NumberFormatException e) { toast("Invalid"); return; }
                if (lim <= 0) { toast("Must be > 0"); return; }
                boolean found = false;
                for (Budget bg : budgets) {
                    if (bg.category.equals(category)) { bg.limit = lim; found = true; break; }
                }
                if (!found) {
                    Budget bg = new Budget();
                    bg.category = category; bg.limit = lim;
                    budgets.add(bg);
                }
                saveBudgets();
                hideKeyboard();
                dialog.dismiss();
                toast("Budget saved");
                showBudgetScreen();
            });
        });
        dialog.show();
    }

    // ======================= REPORTS =======================
    private void showReportsScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Monthly Reports");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        // মাস/বছর নির্বাচন
        final Calendar selected = Calendar.getInstance();
        TextView selBtn = new TextView(this);
        selBtn.setText(new SimpleDateFormat("MMMM yyyy", Locale.US).format(selected.getTime()) + " ▾");
        selBtn.setTextColor(COLOR_TEXT);
        selBtn.setTextSize(15f);
        selBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        selBtn.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable sBg = new GradientDrawable();
        sBg.setColor(COLOR_CARD); sBg.setCornerRadius(dp(12)); sBg.setStroke(dp(1), COLOR_BORDER);
        selBtn.setBackground(sBg);
        col.addView(selBtn);
        col.addView(spacer(dp(16)));

        final LinearLayout reportHost = new LinearLayout(this);
        reportHost.setOrientation(LinearLayout.VERTICAL);
        col.addView(reportHost);

        final Runnable rebuild = () -> {
            reportHost.removeAllViews();
            buildMonthlyReport(reportHost, selected);
        };
        rebuild.run();

        selBtn.setOnClickListener(v -> {
            Calendar cur = Calendar.getInstance();
            cur.setTimeInMillis(selected.getTimeInMillis());
            new DatePickerDialog(this, (dp, y, m, d) -> {
                selected.set(y, m, 1);
                selBtn.setText(new SimpleDateFormat("MMMM yyyy", Locale.US).format(selected.getTime()) + " ▾");
                rebuild.run();
            }, cur.get(Calendar.YEAR), cur.get(Calendar.MONTH), 1).show();
        });

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void buildMonthlyReport(LinearLayout host, Calendar ref) {
        double inc = 0, exp = 0;
        Map<String, Double> catSpend = new HashMap<>();
        int daysCounted = 0;
        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);
        Calendar prev = (Calendar) ref.clone();
        prev.add(Calendar.MONTH, -1);
        double prevInc = 0, prevExp = 0;
        java.util.Set<Integer> days = new java.util.HashSet<>();

        for (Transaction t : transactions) {
            if (isSameMonth(t.timestamp, ref)) {
                if (t.isIncome) inc += t.amount;
                else {
                    exp += t.amount;
                    catSpend.put(t.category, catSpend.getOrDefault(t.category, 0.0) + t.amount);
                    Calendar c = Calendar.getInstance(); c.setTimeInMillis(t.timestamp);
                    days.add(c.get(Calendar.DAY_OF_MONTH));
                }
            } else if (isSameMonth(t.timestamp, prev)) {
                if (t.isIncome) prevInc += t.amount;
                else prevExp += t.amount;
            }
        }
        daysCounted = Math.max(1, days.size());

        double savings = inc - exp;
        double rate = inc > 0 ? (savings / inc) * 100 : 0;

        LinearLayout sumCard = makeCard();
        sumCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        sumCard.addView(detailLine("Income", money(inc)));
        sumCard.addView(detailLine("Expense", money(exp)));
        sumCard.addView(detailLine("Savings", money(savings)));
        sumCard.addView(detailLine("Savings Rate", String.format(Locale.US, "%.1f%%", rate)));
        host.addView(sumCard);
        host.addView(spacer(dp(12)));

        // তুলনা
        LinearLayout cmpCard = makeCard();
        cmpCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView cmpT = new TextView(this);
        cmpT.setText("vs Last Month");
        cmpT.setTextColor(COLOR_TEXT); cmpT.setTextSize(15f);
        cmpT.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        cmpCard.addView(cmpT);
        cmpCard.addView(spacer(dp(8)));

        double incPct = prevInc > 0 ? ((inc - prevInc) / prevInc) * 100 : 0;
        double expPct = prevExp > 0 ? ((exp - prevExp) / prevExp) * 100 : 0;
        cmpCard.addView(buildCmpRow("Income", prevInc, inc, incPct));
        cmpCard.addView(buildCmpRow("Expense", prevExp, exp, expPct));
        host.addView(cmpCard);
        host.addView(spacer(dp(12)));

        // বার চার্ট: গত ৬ মাস
        LinearLayout chartCard = makeCard();
        chartCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView chT = new TextView(this);
        chT.setText("Last 6 Months");
        chT.setTextColor(COLOR_TEXT); chT.setTextSize(15f);
        chT.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        chartCard.addView(chT);

        List<String> labels = new ArrayList<>();
        List<Double> incList = new ArrayList<>();
        List<Double> expList = new ArrayList<>();
        Calendar c = (Calendar) ref.clone();
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.add(Calendar.MONTH, -5);
        for (int i = 0; i < 6; i++) {
            Calendar mRef = (Calendar) c.clone();
            mRef.add(Calendar.MONTH, i);
            double mi = 0, me = 0;
            for (Transaction t : transactions) {
                if (isSameMonth(t.timestamp, mRef)) {
                    if (t.isIncome) mi += t.amount; else me += t.amount;
                }
            }
            labels.add(new SimpleDateFormat("MMM", Locale.US).format(mRef.getTime()));
            incList.add(mi); expList.add(me);
        }
        BarChartView bc = new BarChartView(this, labels, incList, expList);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(200));
        blp.topMargin = dp(12);
        chartCard.addView(bc, blp);
        host.addView(chartCard);
        host.addView(spacer(dp(12)));

        // শীর্ষ ক্যাটেগরি
        LinearLayout topCard = makeCard();
        topCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView topT = new TextView(this);
        topT.setText("Top Expense Category");
        topT.setTextColor(COLOR_TEXT); topT.setTextSize(15f);
        topT.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        topCard.addView(topT);
        String topCat = "—"; double topAmt = 0;
        for (Map.Entry<String, Double> e : catSpend.entrySet()) {
            if (e.getValue() > topAmt) { topAmt = e.getValue(); topCat = e.getKey(); }
        }
        TextView topV = new TextView(this);
        topV.setText(topCat + " · " + money(topAmt));
        topV.setTextColor(COLOR_EXPENSE);
        topV.setTextSize(15f);
        topV.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        topV.setPadding(0, dp(8), 0, 0);
        topCard.addView(topV);
        host.addView(topCard);
        host.addView(spacer(dp(12)));

        // গড় দৈনিক খরচ
        LinearLayout avgCard = makeCard();
        avgCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        avgCard.addView(detailLine("Avg Daily Expense", money(exp / daysCounted)));
        host.addView(avgCard);
    }

    private View buildCmpRow(String label, double prevVal, double curVal, double pct) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        row.addView(mutedText(label), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = new TextView(this);
        String sign = pct >= 0 ? "+" : "";
        v.setText(sign + String.format(Locale.US, "%.1f%%", pct));
        v.setTextColor(pct >= 0 ? COLOR_INCOME : COLOR_EXPENSE);
        v.setTextSize(13f);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        row.addView(v);
        return row;
    }

    // ======================= CATEGORIES =======================
    private void showCategoryManager() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Manage Categories");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        col.addView(buildCategorySection("Income Categories", incomeCategories, true));
        col.addView(spacer(dp(16)));
        col.addView(buildCategorySection("Expense Categories", expenseCategories, false));

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildCategorySection(String title, List<String> cats, boolean isIncomeList) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(COLOR_TEXT);
        t.setTextSize(16f);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setPadding(0, 0, 0, dp(8));
        wrap.addView(t);

        for (final String c : new ArrayList<>(cats)) {
            LinearLayout row = makeCard();
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(14), dp(16), dp(14));

            TextView name = new TextView(this);
            name.setText(c);
            name.setTextColor(COLOR_TEXT);
            name.setTextSize(14f);
            row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView editBtn = new TextView(this);
            editBtn.setText("Edit");
            editBtn.setTextColor(COLOR_ACCENT);
            editBtn.setTextSize(13f);
            editBtn.setPadding(dp(8), dp(6), dp(8), dp(6));
            editBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            editBtn.setOnClickListener(v -> renameCategory(c, isIncomeList));
            row.addView(editBtn);

            if (!"Other".equals(c)) {
                TextView delBtn = new TextView(this);
                delBtn.setText("Del");
                delBtn.setTextColor(COLOR_EXPENSE);
                delBtn.setTextSize(13f);
                delBtn.setPadding(dp(8), dp(6), dp(8), dp(6));
                delBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                delBtn.setOnClickListener(v -> deleteCategory(c, isIncomeList));
                row.addView(delBtn);
            }

            wrap.addView(row);
            wrap.addView(spacer(dp(8)));
        }

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Add Category");
        addBtn.setTextColor(COLOR_ACCENT);
        addBtn.setTextSize(14f);
        addBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        addBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD);
        abg.setCornerRadius(dp(12));
        abg.setStroke(dp(1), COLOR_ACCENT);
        addBtn.setBackground(abg);
        addBtn.setGravity(Gravity.CENTER);
        addBtn.setOnClickListener(v -> addCategory(isIncomeList));
        wrap.addView(addBtn);

        return wrap;
    }

    private void addCategory(final boolean isIncomeList) {
        final EditText input = makeInput("Category name", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("Add " + (isIncomeList ? "Income" : "Expense") + " Category");
        title.setTextColor(COLOR_TEXT); title.setTextSize(17f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(10)));
        box.addView(input);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Add", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { toast("Enter name"); return; }
                List<String> list = isIncomeList ? incomeCategories : expenseCategories;
                if (list.contains(name)) { toast("Already exists"); return; }
                list.add(name);
                saveCategories();
                dialog.dismiss();
                toast("Category added");
                showCategoryManager();
            });
        });
        dialog.show();
    }

    private void renameCategory(final String oldName, final boolean isIncomeList) {
        final EditText input = makeInput("New name", oldName,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("Rename Category");
        title.setTextColor(COLOR_TEXT); title.setTextSize(17f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(10)));
        box.addView(input);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Save", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String newName = input.getText().toString().trim();
                if (newName.isEmpty()) { toast("Enter name"); return; }
                if (newName.equals(oldName)) { dialog.dismiss(); return; }
                List<String> list = isIncomeList ? incomeCategories : expenseCategories;
                if (list.contains(newName)) { toast("Already exists"); return; }
                int idx = list.indexOf(oldName);
                if (idx < 0) { dialog.dismiss(); return; }
                list.set(idx, newName);
                for (Transaction t : transactions) if (oldName.equals(t.category)) t.category = newName;
                saveTransactions(); saveCategories();
                dialog.dismiss();
                toast("Renamed");
                showCategoryManager();
            });
        });
        dialog.show();
    }

    private void deleteCategory(final String name, final boolean isIncomeList) {
        new AlertDialog.Builder(this)
                .setTitle("Delete category?")
                .setMessage("Transactions in \"" + name + "\" will be moved to \"Other\".")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    List<String> list = isIncomeList ? incomeCategories : expenseCategories;
                    list.remove(name);
                    if (!list.contains("Other")) list.add("Other");
                    for (Transaction t : transactions) if (name.equals(t.category)) t.category = "Other";
                    saveTransactions(); saveCategories();
                    toast("Category deleted");
                    showCategoryManager();
                }).show();
    }

    // ======================= RECURRING =======================
    private void showRecurringList() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Recurring Transactions");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        TextView addBtn = new TextView(this);
        addBtn.setText("+ New Recurring");
        addBtn.setTextColor(COLOR_ACCENT);
        addBtn.setTextSize(14f);
        addBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        addBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD); abg.setCornerRadius(dp(12)); abg.setStroke(dp(1), COLOR_ACCENT);
        addBtn.setBackground(abg);
        addBtn.setGravity(Gravity.CENTER);
        addBtn.setOnClickListener(v -> openRecurringForm(null));
        col.addView(addBtn);
        col.addView(spacer(dp(16)));

        if (recurrings.isEmpty()) {
            col.addView(buildEmptyState());
        } else {
            for (final Recurring r : new ArrayList<>(recurrings)) {
                LinearLayout row = makeCard();
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(16), dp(16), dp(16), dp(16));

                TextView desc = new TextView(this);
                desc.setText(r.description + (r.active ? "" : " (paused)"));
                desc.setTextColor(r.active ? COLOR_TEXT : COLOR_TEXT_MUTED);
                desc.setTextSize(15f);
                desc.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                row.addView(desc);

                String intervalStr = r.interval == 1 ? "Daily" : (r.interval == 7 ? "Weekly" : "Monthly");
                TextView meta = mutedText(intervalStr + " · " + r.category + " · " + money(r.amount));
                meta.setPadding(0, dp(4), 0, 0);
                row.addView(meta);

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setPadding(0, dp(10), 0, 0);

                TextView toggle = new TextView(this);
                toggle.setText(r.active ? "Pause" : "Resume");
                toggle.setTextColor(0xFFFFC107);
                toggle.setTextSize(13f);
                toggle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                toggle.setPadding(dp(8), dp(6), dp(8), dp(6));
                toggle.setOnClickListener(v -> {
                    r.active = !r.active;
                    saveRecurrings();
                    showRecurringList();
                });
                actions.addView(toggle);

                TextView edit = new TextView(this);
                edit.setText("Edit");
                edit.setTextColor(COLOR_ACCENT);
                edit.setTextSize(13f);
                edit.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                edit.setPadding(dp(8), dp(6), dp(8), dp(6));
                edit.setOnClickListener(v -> openRecurringForm(r));
                actions.addView(edit);

                TextView del = new TextView(this);
                del.setText("Delete");
                del.setTextColor(COLOR_EXPENSE);
                del.setTextSize(13f);
                del.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                del.setPadding(dp(8), dp(6), dp(8), dp(6));
                del.setOnClickListener(v -> {
                    recurrings.remove(r);
                    saveRecurrings();
                    toast("Recurring deleted");
                    showRecurringList();
                });
                actions.addView(del);
                row.addView(actions);

                col.addView(row);
                col.addView(spacer(dp(10)));
            }
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void openRecurringForm(final Recurring existing) {
        final boolean editing = existing != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText(editing ? "Edit Recurring" : "New Recurring");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final boolean[] isIncome = { editing && existing.isIncome };
        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        final TextView incChip = makeTypeChip("Income", true, isIncome[0]);
        final TextView expChip = makeTypeChip("Expense", false, !isIncome[0]);
        LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        c1.rightMargin = dp(6);
        LinearLayout.LayoutParams c2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        c2.leftMargin = dp(6);
        typeRow.addView(incChip, c1);
        typeRow.addView(expChip, c2);
        box.addView(typeRow);
        box.addView(spacer(dp(12)));

        final EditText descInput = makeInput("Description", editing ? existing.description : "",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(descInput);
        box.addView(spacer(dp(10)));

        final EditText amountInput = makeInput("Amount (" + currencySymbol + ")",
                editing ? trimTrailingZeros(existing.amount) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amountInput);
        box.addView(spacer(dp(10)));

        TextView iLbl = mutedText("Interval"); iLbl.setPadding(0,0,0,dp(6)); box.addView(iLbl);
        final Spinner iSpinner = new Spinner(this);
        ArrayAdapter<String> ia = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Daily", "Weekly", "Monthly"});
        ia.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        iSpinner.setAdapter(ia);
        if (editing) iSpinner.setSelection(existing.interval == 1 ? 0 : (existing.interval == 7 ? 1 : 2));
        box.addView(iSpinner);
        box.addView(spacer(dp(10)));

        TextView catLbl = mutedText("Category"); catLbl.setPadding(0,0,0,dp(6)); box.addView(catLbl);
        final Spinner catSpinner = new Spinner(this);
        final String[] incomeCats = incomeCategories.toArray(new String[0]);
        final String[] expenseCats = expenseCategories.toArray(new String[0]);
        setCategories(catSpinner, isIncome[0] ? incomeCats : expenseCats);
        if (editing) {
            String[] src = existing.isIncome ? incomeCats : expenseCats;
            for (int i = 0; i < src.length; i++) if (src[i].equals(existing.category)) { catSpinner.setSelection(i); break; }
        }
        box.addView(catSpinner);
        box.addView(spacer(dp(10)));

        final Spinner walletSpinner = new Spinner(this);
        List<String> walletNames = new ArrayList<>();
        final List<String> walletIds = new ArrayList<>();
        for (Wallet w : wallets) { walletNames.add(w.name); walletIds.add(w.id); }
        ArrayAdapter<String> wa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, walletNames);
        wa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        walletSpinner.setAdapter(wa);
        if (editing) {
            int wi = walletIds.indexOf(existing.walletId);
            if (wi >= 0) walletSpinner.setSelection(wi);
        }
        box.addView(walletSpinner);

        incChip.setOnClickListener(v -> {
            isIncome[0] = true;
            styleTypeChip(incChip, true, true); styleTypeChip(expChip, false, false);
            setCategories(catSpinner, incomeCats);
        });
        expChip.setOnClickListener(v -> {
            isIncome[0] = false;
            styleTypeChip(expChip, false, true); styleTypeChip(incChip, true, false);
            setCategories(catSpinner, expenseCats);
        });

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton(editing ? "Save" : "Add", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String desc = descInput.getText().toString().trim();
                String amtStr = amountInput.getText().toString().trim();
                Object selCat = catSpinner.getSelectedItem();
                String category = selCat == null ? "Other" : selCat.toString();
                if (desc.isEmpty()) { toast("Enter description"); return; }
                double amount;
                try { amount = Double.parseDouble(amtStr); } catch (Exception e) { toast("Invalid amount"); return; }
                if (amount <= 0) { toast("Amount must be > 0"); return; }
                int interval = iSpinner.getSelectedItemPosition() == 0 ? 1 :
                        (iSpinner.getSelectedItemPosition() == 1 ? 7 : 30);
                int wi = walletSpinner.getSelectedItemPosition();
                String walletId = wi >= 0 && wi < walletIds.size() ? walletIds.get(wi) : "cash";

                if (editing) {
                    existing.description = desc;
                    existing.amount = amount;
                    existing.isIncome = isIncome[0];
                    existing.category = category;
                    existing.interval = interval;
                    existing.walletId = walletId;
                } else {
                    Recurring r = new Recurring();
                    r.id = UUID.randomUUID().toString();
                    r.description = desc; r.amount = amount;
                    r.isIncome = isIncome[0]; r.category = category;
                    r.interval = interval; r.walletId = walletId;
                    r.lastRun = System.currentTimeMillis();
                    r.active = true;
                    recurrings.add(r);
                }
                saveRecurrings();
                hideKeyboard();
                dialog.dismiss();
                toast(editing ? "Recurring updated" : "Recurring added");
                showRecurringList();
            });
        });
        dialog.show();
    }

    // ======================= SAVINGS GOALS =======================
    private void showGoalsScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Savings Goals");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        TextView addBtn = new TextView(this);
        addBtn.setText("+ New Goal");
        addBtn.setTextColor(COLOR_ACCENT);
        addBtn.setTextSize(14f);
        addBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        addBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD); abg.setCornerRadius(dp(12)); abg.setStroke(dp(1), COLOR_ACCENT);
        addBtn.setBackground(abg); addBtn.setGravity(Gravity.CENTER);
        addBtn.setOnClickListener(v -> openGoalForm(null));
        col.addView(addBtn);
        col.addView(spacer(dp(16)));

        if (goals.isEmpty()) {
            col.addView(buildEmptyState());
        } else {
            for (final Goal g : new ArrayList<>(goals)) {
                LinearLayout row = makeCard();
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(16), dp(16), dp(16), dp(16));

                TextView gName = new TextView(this);
                gName.setText(g.name);
                gName.setTextColor(COLOR_TEXT); gName.setTextSize(15f);
                gName.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                row.addView(gName);

                double pct = g.target > 0 ? g.saved / g.target : 0;
                LinearLayout bar = new LinearLayout(this);
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(10));
                blp.topMargin = dp(10);
                bar.setLayoutParams(blp);
                GradientDrawable bg = new GradientDrawable();
                bg.setCornerRadius(dp(5)); bg.setColor(COLOR_CARD_2);
                bar.setBackground(bg);
                View fill = new View(this);
                fill.setBackgroundColor(pct >= 1.0 ? COLOR_INCOME : COLOR_ACCENT);
                float f = (float) Math.min(1.0, pct);
                bar.addView(fill, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, f));
                View empty = new View(this);
                bar.addView(empty, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, Math.max(0.001f, 1f - f)));
                row.addView(bar);

                TextView meta = mutedText(money(g.saved) + " / " + money(g.target) + " · " + (int) Math.round(pct * 100) + "%");
                meta.setPadding(0, dp(6), 0, 0);
                row.addView(meta);

                if (g.deadline > 0) {
                    TextView dl = mutedText("Deadline: " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(g.deadline)));
                    dl.setPadding(0, dp(3), 0, 0);
                    row.addView(dl);
                }

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setPadding(0, dp(10), 0, 0);

                TextView add = new TextView(this);
                add.setText("+ Add");
                add.setTextColor(COLOR_INCOME);
                add.setTextSize(13f);
                add.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                add.setPadding(dp(8), dp(6), dp(8), dp(6));
                add.setOnClickListener(v -> addGoalContribution(g, true));
                actions.addView(add);

                TextView withdraw = new TextView(this);
                withdraw.setText("− Withdraw");
                withdraw.setTextColor(0xFFFFC107);
                withdraw.setTextSize(13f);
                withdraw.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                withdraw.setPadding(dp(8), dp(6), dp(8), dp(6));
                withdraw.setOnClickListener(v -> addGoalContribution(g, false));
                actions.addView(withdraw);

                TextView del = new TextView(this);
                del.setText("Delete");
                del.setTextColor(COLOR_EXPENSE);
                del.setTextSize(13f);
                del.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                del.setPadding(dp(8), dp(6), dp(8), dp(6));
                del.setOnClickListener(v -> {
                    goals.remove(g);
                    saveGoals();
                    toast("Goal deleted");
                    showGoalsScreen();
                });
                actions.addView(del);

                row.addView(actions);
                col.addView(row);
                col.addView(spacer(dp(10)));
            }
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void openGoalForm(final Goal existing) {
        final boolean editing = existing != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText(editing ? "Edit Goal" : "New Goal");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final EditText nameInput = makeInput("Goal name", editing ? existing.name : "",
                InputType.TYPE_CLASS_TEXT);
        box.addView(nameInput);
        box.addView(spacer(dp(10)));

        final EditText targetInput = makeInput("Target (" + currencySymbol + ")",
                editing ? trimTrailingZeros(existing.target) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(targetInput);
        box.addView(spacer(dp(10)));

        final long[] deadlineHolder = { editing ? existing.deadline : 0 };
        TextView dateBtn = new TextView(this);
        dateBtn.setText(deadlineHolder[0] > 0
                ? "Deadline: " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(deadlineHolder[0]))
                : "Pick deadline (optional)");
        dateBtn.setTextColor(COLOR_TEXT); dateBtn.setTextSize(14f);
        dateBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(COLOR_CARD_2); dbg.setCornerRadius(dp(12)); dbg.setStroke(dp(1), COLOR_BORDER);
        dateBtn.setBackground(dbg);
        dateBtn.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (dp, y, m, d) -> {
                Calendar deadlineCalendar = Calendar.getInstance();
                deadlineCalendar.set(y, m, d);
                deadlineHolder[0] = deadlineCalendar.getTimeInMillis();
                dateBtn.setText("Deadline: " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(deadlineCalendar.getTime()));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        box.addView(dateBtn);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton(editing ? "Save" : "Add", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String name = nameInput.getText().toString().trim();
                String tgt = targetInput.getText().toString().trim();
                if (name.isEmpty()) { toast("Enter name"); return; }
                double target;
                try { target = Double.parseDouble(tgt); } catch (Exception e) { toast("Invalid target"); return; }
                if (target <= 0) { toast("Target must be > 0"); return; }
                if (editing) {
                    existing.name = name;
                    existing.target = target;
                    existing.deadline = deadlineHolder[0];
                } else {
                    Goal g = new Goal();
                    g.id = UUID.randomUUID().toString();
                    g.name = name; g.target = target; g.saved = 0;
                    g.deadline = deadlineHolder[0];
                    goals.add(g);
                }
                saveGoals(); hideKeyboard(); dialog.dismiss();
                toast(editing ? "Goal updated" : "Goal added");
                showGoalsScreen();
            });
        });
        dialog.show();
    }

    private void addGoalContribution(final Goal g, final boolean add) {
        final EditText input = makeInput("Amount (" + currencySymbol + ")", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText(add ? "Add to Goal" : "Withdraw from Goal");
        title.setTextColor(COLOR_TEXT); title.setTextSize(17f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(10)));
        box.addView(input);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton(add ? "Add" : "Withdraw", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String s = input.getText().toString().trim();
                double amt;
                try { amt = Double.parseDouble(s); } catch (Exception e) { toast("Invalid"); return; }
                if (amt <= 0) { toast("Must be > 0"); return; }
                if (add) g.saved += amt;
                else g.saved = Math.max(0, g.saved - amt);
                saveGoals();
                dialog.dismiss();
                if (g.saved >= g.target && g.target > 0) {
                    toast("🎉 Congratulations! Goal '" + g.name + "' achieved!");
                } else {
                    toast(add ? "Added" : "Withdrawn");
                }
                showGoalsScreen();
            });
        });
        dialog.show();
    }

    // ======================= DEBTS =======================
    private void showDebtsScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Debts & Loans");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        double totalOwedToMe = 0, totalIOwe = 0;
        for (Debt d : debts) {
            if (d.isPaid()) continue;
            if (d.iGave) totalOwedToMe += d.remaining();
            else totalIOwe += d.remaining();
        }

        LinearLayout sumCard = makeCard();
        sumCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout sumRow = new LinearLayout(this);
        sumRow.setOrientation(LinearLayout.HORIZONTAL);
        sumRow.addView(makeStatBlock("Owed to me", money(totalOwedToMe), COLOR_INCOME), weightParams2());
        sumRow.addView(makeStatBlock("I owe", money(totalIOwe), COLOR_EXPENSE), weightParams2());
        sumCard.addView(sumRow);
        col.addView(sumCard);
        col.addView(spacer(dp(16)));

        TextView addBtn = new TextView(this);
        addBtn.setText("+ New Entry");
        addBtn.setTextColor(COLOR_ACCENT);
        addBtn.setTextSize(14f);
        addBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        addBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD); abg.setCornerRadius(dp(12)); abg.setStroke(dp(1), COLOR_ACCENT);
        addBtn.setBackground(abg); addBtn.setGravity(Gravity.CENTER);
        addBtn.setOnClickListener(v -> openDebtForm());
        col.addView(addBtn);
        col.addView(spacer(dp(16)));

        if (debts.isEmpty()) {
            col.addView(buildEmptyState());
        } else {
            for (final Debt d : new ArrayList<>(debts)) {
                LinearLayout row = makeCard();
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(16), dp(16), dp(16), dp(16));

                LinearLayout headRow = new LinearLayout(this);
                headRow.setOrientation(LinearLayout.HORIZONTAL);

                TextView person = new TextView(this);
                person.setText(d.person + (d.isPaid() ? "  ✓ Paid" : ""));
                person.setTextColor(d.isPaid() ? COLOR_INCOME : COLOR_TEXT);
                person.setTextSize(15f);
                person.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                headRow.addView(person, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                TextView amt = new TextView(this);
                amt.setText((d.iGave ? "+" : "-") + money(d.remaining()));
                amt.setTextColor(d.iGave ? COLOR_INCOME : COLOR_EXPENSE);
                amt.setTextSize(15f);
                amt.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                headRow.addView(amt);
                row.addView(headRow);

                String info = (d.iGave ? "I gave to " : "I took from ") + d.person
                        + " · " + new SimpleDateFormat("dd MMM", Locale.US).format(new Date(d.date));
                if (d.dueDate > 0) info += " · Due " + new SimpleDateFormat("dd MMM", Locale.US).format(new Date(d.dueDate));
                TextView meta = mutedText(info);
                meta.setPadding(0, dp(4), 0, 0);
                row.addView(meta);

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setPadding(0, dp(10), 0, 0);

                if (!d.isPaid()) {
                    TextView pay = new TextView(this);
                    pay.setText("Add Payment");
                    pay.setTextColor(COLOR_INCOME);
                    pay.setTextSize(13f);
                    pay.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                    pay.setPadding(dp(8), dp(6), dp(8), dp(6));
                    pay.setOnClickListener(v -> addDebtPayment(d));
                    actions.addView(pay);
                }

                TextView del = new TextView(this);
                del.setText("Delete");
                del.setTextColor(COLOR_EXPENSE);
                del.setTextSize(13f);
                del.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                del.setPadding(dp(8), dp(6), dp(8), dp(6));
                del.setOnClickListener(v -> {
                    debts.remove(d);
                    saveDebts();
                    toast("Debt deleted");
                    showDebtsScreen();
                });
                actions.addView(del);
                row.addView(actions);

                col.addView(row);
                col.addView(spacer(dp(10)));
            }
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void openDebtForm() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("New Debt Entry");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final boolean[] iGave = { true };
        LinearLayout typeRow = new LinearLayout(this);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        final TextView gaveChip = makeTypeChip("I Gave", true, true);
        final TextView tookChip = makeTypeChip("I Took", false, false);
        LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        c1.rightMargin = dp(6);
        LinearLayout.LayoutParams c2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        c2.leftMargin = dp(6);
        typeRow.addView(gaveChip, c1);
        typeRow.addView(tookChip, c2);
        box.addView(typeRow);
        box.addView(spacer(dp(10)));

        final EditText personInput = makeInput("Person name", "", InputType.TYPE_CLASS_TEXT);
        box.addView(personInput);
        box.addView(spacer(dp(10)));

        final EditText amountInput = makeInput("Amount (" + currencySymbol + ")", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amountInput);
        box.addView(spacer(dp(10)));

        final long[] dueHolder = { 0 };
        TextView dueBtn = new TextView(this);
        dueBtn.setText("Pick due date (optional)");
        dueBtn.setTextColor(COLOR_TEXT); dueBtn.setTextSize(14f);
        dueBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(COLOR_CARD_2); dbg.setCornerRadius(dp(12)); dbg.setStroke(dp(1), COLOR_BORDER);
        dueBtn.setBackground(dbg);
        dueBtn.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (dp, y, m, d) -> {
                Calendar dueCal = Calendar.getInstance();
                dueCal.set(y, m, d);
                dueHolder[0] = dueCal.getTimeInMillis();
                dueBtn.setText("Due: " + new SimpleDateFormat("dd MMM yyyy", Locale.US).format(dueCal.getTime()));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        box.addView(dueBtn);

        final EditText noteInput = makeInput("Note (optional)", "", InputType.TYPE_CLASS_TEXT);
        box.addView(noteInput);

        gaveChip.setOnClickListener(v -> { iGave[0] = true; styleTypeChip(gaveChip, true, true); styleTypeChip(tookChip, false, false); });
        tookChip.setOnClickListener(v -> { iGave[0] = false; styleTypeChip(tookChip, false, true); styleTypeChip(gaveChip, true, false); });

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Add", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String person = personInput.getText().toString().trim();
                String amtStr = amountInput.getText().toString().trim();
                if (person.isEmpty()) { toast("Enter person name"); return; }
                double amt;
                try { amt = Double.parseDouble(amtStr); } catch (Exception e) { toast("Invalid amount"); return; }
                if (amt <= 0) { toast("Must be > 0"); return; }
                Debt d2 = new Debt();
                d2.id = UUID.randomUUID().toString();
                d2.person = person; d2.amount = amt; d2.paid = 0;
                d2.date = System.currentTimeMillis();
                d2.dueDate = dueHolder[0];
                d2.iGave = iGave[0];
                d2.note = noteInput.getText().toString().trim();
                debts.add(d2);
                saveDebts(); hideKeyboard(); dialog.dismiss();
                toast("Entry added");
                showDebtsScreen();
            });
        });
        dialog.show();
    }

    private void addDebtPayment(final Debt d) {
        final EditText input = makeInput("Payment amount (" + currencySymbol + ")",
                trimTrailingZeros(d.remaining()),
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("Add Payment · " + d.person);
        title.setTextColor(COLOR_TEXT); title.setTextSize(17f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(10)));
        box.addView(input);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Save", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(dd -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String s = input.getText().toString().trim();
                double amt;
                try { amt = Double.parseDouble(s); } catch (Exception e) { toast("Invalid"); return; }
                if (amt <= 0) { toast("Must be > 0"); return; }
                d.paid = Math.min(d.amount, d.paid + amt);
                saveDebts(); dialog.dismiss();
                toast(d.isPaid() ? "Fully paid!" : "Payment recorded");
                showDebtsScreen();
            });
        });
        dialog.show();
    }

    // ======================= WALLETS =======================
    private void showWalletsScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Wallets");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView addBtn = new TextView(this);
        addBtn.setText("+ Wallet");
        addBtn.setTextColor(COLOR_ACCENT);
        addBtn.setTextSize(14f);
        addBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        addBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        addBtn.setGravity(Gravity.CENTER);
        GradientDrawable abg = new GradientDrawable();
        abg.setColor(COLOR_CARD); abg.setCornerRadius(dp(12)); abg.setStroke(dp(1), COLOR_ACCENT);
        addBtn.setBackground(abg);
        addBtn.setOnClickListener(v -> openWalletForm(null));
        actionRow.addView(addBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView xferBtn = new TextView(this);
        xferBtn.setText("⇄ Transfer");
        xferBtn.setTextColor(COLOR_TEXT);
        xferBtn.setTextSize(14f);
        xferBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        xferBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        xferBtn.setGravity(Gravity.CENTER);
        GradientDrawable xbg = new GradientDrawable();
        xbg.setColor(COLOR_CARD); xbg.setCornerRadius(dp(12)); xbg.setStroke(dp(1), COLOR_BORDER);
        xferBtn.setBackground(xbg);
        xferBtn.setOnClickListener(v -> transferBetweenWallets());
        LinearLayout.LayoutParams xlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        xlp.leftMargin = dp(10);
        actionRow.addView(xferBtn, xlp);

        col.addView(actionRow);
        col.addView(spacer(dp(16)));

        for (final Wallet w : new ArrayList<>(wallets)) {
            LinearLayout row = makeCard();
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(16), dp(16), dp(16), dp(16));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            TextView name = new TextView(this);
            name.setText(w.name);
            name.setTextColor(COLOR_TEXT); name.setTextSize(15f);
            name.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView bal = new TextView(this);
            bal.setText(money(walletBalance(w.id)));
            bal.setTextColor(COLOR_ACCENT); bal.setTextSize(15f);
            bal.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            top.addView(bal);
            row.addView(top);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, dp(8), 0, 0);

            TextView edit = new TextView(this);
            edit.setText("Edit");
            edit.setTextColor(COLOR_ACCENT);
            edit.setTextSize(13f);
            edit.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            edit.setPadding(dp(8), dp(6), dp(8), dp(6));
            edit.setOnClickListener(v -> openWalletForm(w));
            actions.addView(edit);

            if (wallets.size() > 1) {
                TextView del = new TextView(this);
                del.setText("Delete");
                del.setTextColor(COLOR_EXPENSE);
                del.setTextSize(13f);
                del.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
                del.setPadding(dp(8), dp(6), dp(8), dp(6));
                del.setOnClickListener(v -> {
                    if ("cash".equals(w.id)) { toast("Cannot delete Cash wallet"); return; }
                    wallets.remove(w);
                    for (Transaction t : transactions) if (w.id.equals(t.walletId)) t.walletId = "cash";
                    saveTransactions(); saveWallets();
                    toast("Wallet deleted; its transactions moved to Cash");
                    showWalletsScreen();
                });
                actions.addView(del);
            }
            row.addView(actions);
            col.addView(row);
            col.addView(spacer(dp(10)));
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void openWalletForm(final Wallet existing) {
        final boolean editing = existing != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText(editing ? "Edit Wallet" : "New Wallet");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final EditText nameInput = makeInput("Wallet name", editing ? existing.name : "", InputType.TYPE_CLASS_TEXT);
        box.addView(nameInput);
        box.addView(spacer(dp(10)));

        final EditText initInput = makeInput("Initial balance (" + currencySymbol + ")",
                editing ? trimTrailingZeros(existing.initial) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(initInput);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton(editing ? "Save" : "Add", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String name = nameInput.getText().toString().trim();
                if (name.isEmpty()) { toast("Enter name"); return; }
                double init = 0;
                try {
                    String s = initInput.getText().toString().trim();
                    if (!s.isEmpty()) init = Double.parseDouble(s);
                } catch (Exception ignored) { }
                if (editing) {
                    existing.name = name;
                    existing.initial = init;
                } else {
                    Wallet w = new Wallet();
                    w.id = UUID.randomUUID().toString();
                    w.name = name;
                    w.initial = init;
                    wallets.add(w);
                }
                saveWallets(); hideKeyboard(); dialog.dismiss();
                toast(editing ? "Wallet updated" : "Wallet added");
                showWalletsScreen();
            });
        });
        dialog.show();
    }

    private void transferBetweenWallets() {
        if (wallets.size() < 2) { toast("Need at least 2 wallets"); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText("Transfer Between Wallets");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        List<String> names = new ArrayList<>();
        final List<String> ids = new ArrayList<>();
        for (Wallet w : wallets) { names.add(w.name); ids.add(w.id); }

        TextView fromLbl = mutedText("From"); fromLbl.setPadding(0,0,0,dp(6)); box.addView(fromLbl);
        final Spinner fromSpinner = new Spinner(this);
        ArrayAdapter<String> fa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        fa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromSpinner.setAdapter(fa);
        box.addView(fromSpinner);
        box.addView(spacer(dp(10)));

        TextView toLbl = mutedText("To"); toLbl.setPadding(0,0,0,dp(6)); box.addView(toLbl);
        final Spinner toSpinner = new Spinner(this);
        ArrayAdapter<String> ta = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toSpinner.setAdapter(ta);
        toSpinner.setSelection(1);
        box.addView(toSpinner);
        box.addView(spacer(dp(10)));

        final EditText amountInput = makeInput("Amount (" + currencySymbol + ")", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amountInput);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Transfer", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                int fi = fromSpinner.getSelectedItemPosition();
                int ti = toSpinner.getSelectedItemPosition();
                if (fi == ti) { toast("Choose different wallets"); return; }
                double amt;
                try { amt = Double.parseDouble(amountInput.getText().toString().trim()); }
                catch (Exception e) { toast("Invalid amount"); return; }
                if (amt <= 0) { toast("Must be > 0"); return; }

                Wallet from = wallets.get(fi), to = wallets.get(ti);
                from.initial -= amt;
                to.initial += amt;
                saveWallets();
                dialog.dismiss();
                toast("Transferred " + money(amt));
                showWalletsScreen();
            });
        });
        dialog.show();
    }

    // ======================= BACKUP / RESTORE / CSV =======================
    private void showBackupScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Backup & Restore");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        col.addView(buildProfileRow("Export JSON Backup", "Save everything to a file",
                () -> exportAllData()));
        col.addView(spacer(dp(10)));
        col.addView(buildProfileRow("Import JSON Backup", "Restore from backup file",
                () -> confirmImportBackup()));
        col.addView(spacer(dp(10)));
        col.addView(buildProfileRow("Export CSV", "Export transactions as CSV spreadsheet",
                () -> exportTransactionsCSV()));

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private String buildFullBackupJson() throws JSONException {
        JSONObject root = new JSONObject();
        JSONArray txns = new JSONArray();
        for (Transaction t : transactions) txns.put(t.toJson());
        root.put("transactions", txns);
        JSONArray bj = new JSONArray(); for (Budget b : budgets) bj.put(b.toJson()); root.put("budgets", bj);
        JSONArray gj = new JSONArray(); for (Goal g : goals) gj.put(g.toJson()); root.put("goals", gj);
        JSONArray dj = new JSONArray(); for (Debt d : debts) dj.put(d.toJson()); root.put("debts", dj);
        JSONArray wj = new JSONArray(); for (Wallet w : wallets) wj.put(w.toJson()); root.put("wallets", wj);
        JSONArray rj = new JSONArray(); for (Recurring r : recurrings) rj.put(r.toJson()); root.put("recurrings", rj);
        JSONArray inc = new JSONArray(); for (String s : incomeCategories) inc.put(s);
        JSONArray exp = new JSONArray(); for (String s : expenseCategories) exp.put(s);
        JSONObject catRoot = new JSONObject(); catRoot.put("income", inc); catRoot.put("expense", exp);
        root.put("categories", catRoot);
        root.put("currency", currencyCode);
        root.put("theme", isLightTheme ? "light" : "dark");
        return root.toString(2);
    }

    private void exportAllData() {
        try {
            String json = buildFullBackupJson();
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE,
                    "money_experts_backup_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".json");
            startActivityForResult(intent, REQ_EXPORT_JSON);
        } catch (Exception e) {
            toast("Export failed: " + e.getMessage());
        }
    }

    private void exportTransactionsCSV() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE,
                "transactions_" + new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT_CSV);
    }

    private void confirmImportBackup() {
        new AlertDialog.Builder(this)
                .setTitle("Import Backup?")
                .setMessage("Existing data will be replaced. This cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Choose File", (d, w) -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, REQ_IMPORT_JSON);
                }).show();
    }

    private static final int REQ_EXPORT_JSON = 5001;
    private static final int REQ_EXPORT_CSV = 5002;
    private static final int REQ_IMPORT_JSON = 5003;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        if (requestCode == REQ_EXPORT_JSON) {
            try {
                String json = buildFullBackupJson();
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os != null) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                    os.close();
                    toast("Backup saved");
                }
            } catch (Exception e) { toast("Export failed: " + e.getMessage()); }
        } else if (requestCode == REQ_EXPORT_CSV) {
            try {
                StringBuilder sb = new StringBuilder();
                sb.append("Date,Time,Description,Category,Wallet,Type,Amount,Note\n");
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                SimpleDateFormat tf = new SimpleDateFormat("HH:mm", Locale.US);
                for (Transaction t : transactions) {
                    Date dt = new Date(t.timestamp);
                    String line = String.join(",",
                            df.format(dt), tf.format(dt),
                            csvEsc(t.description), csvEsc(t.category),
                            csvEsc(walletNameById(t.walletId)),
                            t.isIncome ? "Income" : "Expense",
                            String.format(Locale.US, "%.2f", t.amount),
                            csvEsc(t.note == null ? "" : t.note));
                    sb.append(line).append("\n");
                }
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os != null) {
                    os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
                    os.close();
                    toast("CSV exported");
                }
            } catch (Exception e) { toast("Export failed: " + e.getMessage()); }
        } else if (requestCode == REQ_IMPORT_JSON) {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) { toast("Cannot open"); return; }
                BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
                br.close();
                String json = sb.toString();
                applyFullBackupJson(json);
                toast("Backup restored");
                showProfile();
            } catch (Exception e) { toast("Import failed: " + e.getMessage()); }
        }
    }

    private String csvEsc(String s) {
        if (s == null) return "";
        String v = s.replace("\"", "\"\"");
        if (v.contains(",") || v.contains("\n") || v.contains("\"")) return "\"" + v + "\"";
        return v;
    }

    private void applyFullBackupJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            transactions.clear();
            JSONArray txns = root.optJSONArray("transactions");
            if (txns != null) for (int i = 0; i < txns.length(); i++) {
                JSONObject o = txns.optJSONObject(i);
                if (o != null) transactions.add(Transaction.fromJson(o));
            }
            budgets.clear();
            JSONArray bj = root.optJSONArray("budgets");
            if (bj != null) for (int i = 0; i < bj.length(); i++) {
                JSONObject o = bj.optJSONObject(i);
                if (o != null) budgets.add(Budget.fromJson(o));
            }
            goals.clear();
            JSONArray gj = root.optJSONArray("goals");
            if (gj != null) for (int i = 0; i < gj.length(); i++) {
                JSONObject o = gj.optJSONObject(i);
                if (o != null) goals.add(Goal.fromJson(o));
            }
            debts.clear();
            JSONArray dj = root.optJSONArray("debts");
            if (dj != null) for (int i = 0; i < dj.length(); i++) {
                JSONObject o = dj.optJSONObject(i);
                if (o != null) debts.add(Debt.fromJson(o));
            }
            wallets.clear();
            JSONArray wj = root.optJSONArray("wallets");
            if (wj != null) for (int i = 0; i < wj.length(); i++) {
                JSONObject o = wj.optJSONObject(i);
                if (o != null) wallets.add(Wallet.fromJson(o));
            }
            recurrings.clear();
            JSONArray rj = root.optJSONArray("recurrings");
            if (rj != null) for (int i = 0; i < rj.length(); i++) {
                JSONObject o = rj.optJSONObject(i);
                if (o != null) recurrings.add(Recurring.fromJson(o));
            }
            JSONObject catRoot = root.optJSONObject("categories");
            if (catRoot != null) {
                incomeCategories.clear(); expenseCategories.clear();
                JSONArray inc = catRoot.optJSONArray("income");
                JSONArray exp = catRoot.optJSONArray("expense");
                if (inc != null) for (int i = 0; i < inc.length(); i++) incomeCategories.add(inc.optString(i));
                if (exp != null) for (int i = 0; i < exp.length(); i++) expenseCategories.add(exp.optString(i));
                if (incomeCategories.isEmpty()) for (String c : DEFAULT_INCOME_CATS.split(",")) incomeCategories.add(c);
                if (expenseCategories.isEmpty()) for (String c : DEFAULT_EXPENSE_CATS.split(",")) expenseCategories.add(c);
            }
            currencyCode = root.optString("currency", currencyCode);
            currencySymbol = symbolForCode(currencyCode);
            isLightTheme = "light".equals(root.optString("theme", isLightTheme ? "light" : "dark"));
            applyTheme();

            saveTransactions(); saveBudgets(); saveGoals(); saveDebts();
            saveWallets(); saveRecurrings(); saveCategories();
            prefs.edit().putString(KEY_CURRENCY, currencyCode)
                    .putString(KEY_THEME, isLightTheme ? "light" : "dark").apply();
        } catch (Exception e) {
            toast("Import failed: " + e.getMessage());
        }
    }

    // ======================= APP LOCK (PIN + BIOMETRIC) =======================
    private String hashPin(String pin) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((pin + "|money_experts_salt").getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    private void showSecurityScreen() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("App Lock & Security");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        boolean lockOn = prefs.getBoolean(KEY_LOCK_ON, false);
        boolean bioOn = prefs.getBoolean(KEY_BIOMETRIC, false);

        LinearLayout card = makeCard();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.addView(detailLine("PIN Lock", lockOn ? "Enabled" : "Disabled"));
        card.addView(detailLine("Biometric", bioOn ? "Enabled" : "Disabled"));
        col.addView(card);
        col.addView(spacer(dp(12)));

        col.addView(buildProfileRow(lockOn ? "Change PIN" : "Set PIN", "4-digit lock code",
                () -> setupPin(lockOn)));
        col.addView(spacer(dp(10)));

        if (lockOn) {
            col.addView(buildProfileRow("Disable Lock", "Remove PIN protection",
                    () -> {
                        new AlertDialog.Builder(this)
                                .setTitle("Disable Lock?")
                                .setMessage("App will open without PIN.")
                                .setNegativeButton("Cancel", null)
                                .setPositiveButton("Disable", (d, w) -> {
                                    prefs.edit().putBoolean(KEY_LOCK_ON, false)
                                            .putString(KEY_PIN_HASH, "").apply();
                                    toast("Lock disabled");
                                    showSecurityScreen();
                                }).show();
                    }));
            col.addView(spacer(dp(10)));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            col.addView(buildProfileRow(
                    bioOn ? "Disable Biometric" : "Enable Biometric",
                    "Use fingerprint to unlock",
                    () -> {
                        prefs.edit().putBoolean(KEY_BIOMETRIC, !bioOn).apply();
                        toast(bioOn ? "Biometric disabled" : "Biometric enabled");
                        showSecurityScreen();
                    }));
        }

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void setupPin(boolean isChange) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(16), dp(20), dp(8));
        TextView title = new TextView(this);
        title.setText(isChange ? "Change PIN" : "Set 4-digit PIN");
        title.setTextColor(COLOR_TEXT); title.setTextSize(18f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(title);
        box.addView(spacer(dp(12)));

        final EditText pin1 = makeInput("Enter 4-digit PIN", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin1.setSingleLine(true);
        box.addView(pin1);
        box.addView(spacer(dp(10)));

        final EditText pin2 = makeInput("Confirm PIN", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin2.setSingleLine(true);
        box.addView(pin2);

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setView(box);
        b.setNegativeButton("Cancel", null);
        b.setPositiveButton("Save", null);
        final AlertDialog dialog = b.create();
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(darkDialogBg());
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            pos.setTextColor(COLOR_ACCENT);
            pos.setOnClickListener(v -> {
                String p1 = pin1.getText().toString().trim();
                String p2 = pin2.getText().toString().trim();
                if (p1.length() != 4) { toast("PIN must be 4 digits"); return; }
                if (!p1.equals(p2)) { toast("PINs don't match"); return; }
                prefs.edit().putString(KEY_PIN_HASH, hashPin(p1))
                        .putBoolean(KEY_LOCK_ON, true).apply();
                hideKeyboard(); dialog.dismiss();
                unlocked = true;
                toast("PIN set");
                showSecurityScreen();
            });
        });
        dialog.show();
    }

    private void showLockScreen() {
        contentHost.removeAllViews();
        if (navBar != null) navBar.setVisibility(View.GONE);

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setBackgroundColor(COLOR_BG);
        wrap.setPadding(dp(24), dp(24), dp(24), dp(24));

        NavIconView lockIcon = new NavIconView(this, NavIcon.WALLET, COLOR_ACCENT);
        wrap.addView(lockIcon, new LinearLayout.LayoutParams(dp(64), dp(64)));

        TextView title = new TextView(this);
        title.setText("Money Experts Locked");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(20f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(16), 0, dp(6));
        wrap.addView(title);

        TextView sub = mutedText("Enter your 4-digit PIN to unlock");
        sub.setGravity(Gravity.CENTER);
        wrap.addView(sub);

        final EditText pin = makeInput("• • • •", "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setSingleLine(true);
        pin.setGravity(Gravity.CENTER);
        pin.setTextSize(22f);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        plp.topMargin = dp(20);
        wrap.addView(pin, plp);

        TextView unlockBtn = new TextView(this);
        unlockBtn.setText("Unlock");
        unlockBtn.setTextColor(Color.BLACK);
        unlockBtn.setGravity(Gravity.CENTER);
        unlockBtn.setTextSize(16f);
        unlockBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        GradientDrawable ubg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{0xFF35D07F, 0xFF1FA05C});
        ubg.setCornerRadius(dp(14));
        unlockBtn.setBackground(ubg);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        ulp.topMargin = dp(14);
        wrap.addView(unlockBtn, ulp);

        unlockBtn.setOnClickListener(v -> {
            String p = pin.getText().toString().trim();
            if (hashPin(p).equals(prefs.getString(KEY_PIN_HASH, ""))) {
                unlocked = true;
                navBar.setVisibility(View.VISIBLE);
                showHome();
            } else {
                toast("Incorrect PIN");
                pin.setText("");
            }
        });

        if (prefs.getBoolean(KEY_BIOMETRIC, false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            TextView bioBtn = new TextView(this);
            bioBtn.setText("Use Biometric");
            bioBtn.setTextColor(COLOR_ACCENT);
            bioBtn.setGravity(Gravity.CENTER);
            bioBtn.setTextSize(14f);
            bioBtn.setPadding(0, dp(14), 0, dp(14));
            bioBtn.setOnClickListener(v -> tryBiometric());
            wrap.addView(bioBtn);
            tryBiometric();
        }

        contentHost.addView(wrap, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void tryBiometric() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return;
        try {
            android.hardware.biometrics.BiometricPrompt.Builder builder =
                    new android.hardware.biometrics.BiometricPrompt.Builder(this)
                            .setTitle("Unlock Money Experts")
                            .setNegativeButton("Cancel", getMainExecutor(), (d, w) -> { });
            builder.build().authenticate(new CancellationSignal(), getMainExecutor(),
                    new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                            runOnUiThread(() -> {
                                unlocked = true;
                                navBar.setVisibility(View.VISIBLE);
                                showHome();
                            });
                        }
                    });
        } catch (Exception e) { }
    }

    // ======================= REMINDERS / NOTIFICATIONS =======================
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    NOTIF_CHANNEL_ID, "Money Experts Reminders", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Daily log reminder");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private void showReminderSettings() {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(0, 0, 0, dp(96));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(20), dp(18), dp(20));
        scroll.addView(col, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Reminders");
        title.setTextColor(COLOR_TEXT); title.setTextSize(22f);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout backBtn = new FrameLayout(this);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(COLOR_CARD); bBg.setCornerRadius(dp(12)); bBg.setStroke(dp(1), COLOR_BORDER);
        backBtn.setBackground(bBg);
        NavIconView backIc = new NavIconView(this, NavIcon.CLOSE, COLOR_TEXT);
        backBtn.addView(backIc, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        backBtn.setOnClickListener(v -> showProfile());
        header.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(header);
        col.addView(spacer(dp(18)));

        boolean on = prefs.getBoolean(KEY_REMINDER_ON, false);
        int hour = prefs.getInt(KEY_REMINDER_HOUR, 20);
        int min = prefs.getInt(KEY_REMINDER_MIN, 0);

        LinearLayout card = makeCard();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.addView(detailLine("Daily reminder", on ? "Enabled" : "Disabled"));
        card.addView(detailLine("Time", String.format(Locale.US, "%02d:%02d", hour, min)));
        col.addView(card);
        col.addView(spacer(dp(12)));

        col.addView(buildProfileRow(on ? "Disable Reminder" : "Enable Reminder",
                on ? "Turn off daily log notification" : "Turn on daily log notification",
                () -> {
                    if (on) {
                        prefs.edit().putBoolean(KEY_REMINDER_ON, false).apply();
                        cancelDailyReminder();
                        toast("Reminder disabled");
                    } else {
                        prefs.edit().putBoolean(KEY_REMINDER_ON, true).apply();
                        scheduleDailyReminder(hour, min);
                        requestNotificationPermission();
                        toast("Reminder enabled");
                    }
                    showReminderSettings();
                }));
        col.addView(spacer(dp(10)));
        col.addView(buildProfileRow("Set Time", "Choose when to be reminded",
                () -> new TimePickerDialog(this, (v, h, m) -> {
                    prefs.edit().putInt(KEY_REMINDER_HOUR, h).putInt(KEY_REMINDER_MIN, m).apply();
                    if (prefs.getBoolean(KEY_REMINDER_ON, false)) scheduleDailyReminder(h, m);
                    toast("Time set");
                    showReminderSettings();
                }, hour, min, false).show()));

        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7001);
                }
            } catch (Exception ignored) { }
        }
    }

    private void scheduleDailyReminder(int hour, int min) {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 9001, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, min);
            c.set(Calendar.SECOND, 0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
            if (Build.VERSION.SDK_INT >= 23) {
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pi);
            } else {
                am.setRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pi);
            }
        } catch (Exception ignored) { }
    }

    private void cancelDailyReminder() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 9001, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            if (am != null) am.cancel(pi);
        } catch (Exception ignored) { }
    }

    public static class ReminderReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                SharedPreferences p = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                if (!p.getBoolean(KEY_REMINDER_ON, false)) return;
                
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm == null) return;

                Intent open = new Intent(context, MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                PendingIntent pi = PendingIntent.getActivity(context, 100,
                        open, PendingIntent.FLAG_UPDATE_CURRENT |
                                (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
                
                Notification.Builder b;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    b = new Notification.Builder(context, NOTIF_CHANNEL_ID);
                } else {
                    b = new Notification.Builder(context);
                }
                
                b.setSmallIcon(android.R.drawable.ic_menu_manage)
                 .setContentTitle("Money Experts")
                 .setContentText("আজকের খরচ লিখেছেন? / Did you log today's expense?")
                 .setAutoCancel(true)
                 .setContentIntent(pi);

                nm.notify(NOTIF_ID_DAILY, b.build());
            } catch (Exception ignored) { }
        }
    }

    public static class BootReceiver extends BroadcastReceiver {
        @Override        
        public void onReceive(Context context, Intent intent) {
            try {
                if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
                SharedPreferences p = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                if (!p.getBoolean(KEY_REMINDER_ON, false)) return;
                int h = p.getInt(KEY_REMINDER_HOUR, 20);
                int m = p.getInt(KEY_REMINDER_MIN, 0);
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (am == null) return;
                Intent i = new Intent(context, ReminderReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(context, 9001, i,
                        PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
                Calendar c = Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY, h);
                c.set(Calendar.MINUTE, m);
                if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY, pi);
            } catch (Exception ignored) { }
        }
    }

    // ======================= UI HELPERS =======================
    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), COLOR_BORDER);
        card.setBackground(bg);
        card.setElevation(dp(2));
        return card;
    }

    private GradientDrawable dangerCardBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isLightTheme ? 0xFFFFF3F3 : 0xFF141010);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0x4DFF5C5C);
        return bg;
    }

    private GradientDrawable darkDialogBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(isLightTheme ? LIGHT_CARD : 0xFF121212);
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), COLOR_BORDER);
        return bg;
    }

    private TextView mutedText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(COLOR_TEXT_MUTED);
        t.setTextSize(13f);
        return t;
    }

    private View spacer(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        return v;
    }

    // ======================= CUSTOM DONUT CHART =======================
    private class DonutChartView extends View {
        private final List<String> cats;
        private final List<Double> vals;
        private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        DonutChartView(Context context, List<String> cats, List<Double> vals) {
            super(context);
            this.cats = cats;
            this.vals = vals;
            arcPaint.setStyle(Paint.Style.STROKE);
            arcPaint.setStrokeWidth(dp(22));
            arcPaint.setStrokeCap(Paint.Cap.BUTT);

            textPaint.setColor(COLOR_TEXT);
            textPaint.setTextSize(dp(20));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float radius = Math.min(w, h) / 2f - dp(30);

            rect.set(cx - radius, cy - radius, cx + radius, cy + radius);

            double total = 0;
            for (double v : vals) total += v;
            if (total == 0) return;

            float startAngle = -90f;

            for (int i = 0; i < vals.size(); i++) {
                float sweep = (float) ((vals.get(i) / total) * 360f);
                arcPaint.setColor(CHART_COLORS[i % CHART_COLORS.length]);
                float gap = sweep > 2f ? 1.5f : 0f;
                canvas.drawArc(rect, startAngle + gap/2, sweep - gap, false, arcPaint);
                startAngle += sweep;
            }

            float textY = cy - (textPaint.descent() + textPaint.ascent()) / 2;
            canvas.drawText(money(totalExpense()), cx, textY, textPaint);

            textPaint.setTextSize(dp(12));
            textPaint.setColor(COLOR_TEXT_MUTED);
            textPaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            canvas.drawText("Total Expenses", cx, textY + dp(20), textPaint);
        }
    }

    // ======================= BAR CHART =======================
    private class BarChartView extends View {
        private final List<String> labels;
        private final List<Double> inc;
        private final List<Double> exp;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

        BarChartView(Context c, List<String> labels, List<Double> inc, List<Double> exp) {
            super(c);
            this.labels = labels; this.inc = inc; this.exp = exp;
            txt.setColor(COLOR_TEXT_MUTED);
            txt.setTextSize(dp(10));
            txt.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float padding = dp(24);
            float chartW = w - padding * 2;
            float chartH = h - dp(40);
            float baseY = h - dp(22);

            double max = 1;
            for (double d : inc) max = Math.max(max, d);
            for (double d : exp) max = Math.max(max, d);

            int n = labels.size();
            if (n == 0) return;
            float groupW = chartW / n;
            float barW = groupW * 0.3f;

            p.setColor(COLOR_BORDER);
            p.setStrokeWidth(dp(1));
            canvas.drawLine(padding, baseY, w - padding, baseY, p);

            for (int i = 0; i < n; i++) {
                float cx = padding + groupW * i + groupW / 2f;

                float ih = (float) (inc.get(i) / max * chartH);
                float eh = (float) (exp.get(i) / max * chartH);

                p.setColor(COLOR_INCOME);
                canvas.drawRoundRect(cx - barW - dp(2), baseY - ih,
                        cx - dp(2), baseY, dp(3), dp(3), p);

                p.setColor(COLOR_EXPENSE);
                canvas.drawRoundRect(cx + dp(2), baseY - eh,
                        cx + barW + dp(2), baseY, dp(3), dp(3), p);

                txt.setColor(COLOR_TEXT_MUTED);
                canvas.drawText(labels.get(i), cx, baseY + dp(14), txt);
            }
        }
    }

    // ======================= NAV ICON =======================
    private static class NavIcon {
        static final int HOME = 0;
        static final int PLUS = 1;
        static final int PROFILE = 2;
        static final int PROFILE_FILLED = 3;
        static final int DOTS = 4;
        static final int ARROW_UP = 5;
        static final int ARROW_DOWN = 6;
        static final int WALLET = 7;
        static final int CLOSE = 8;
        static final int CHART = 9;
    }

    private class NavIconView extends View {
        private final int type;
        private int tint;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        NavIconView(Context c, int type, int tint) {
            super(c);
            this.type = type;
            this.tint = tint;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(tint);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float size = Math.min(w, h);
            paint.setColor(tint);

            switch (type) {
                case NavIcon.HOME: {
                    float s = size * 0.55f;
                    float left = cx - s / 2f;
                    float top = cy - s / 2f;
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.085f);
                    Path p = new Path();
                    p.moveTo(left, cy + s * 0.05f);
                    p.lineTo(cx, top);
                    p.lineTo(left + s, cy + s * 0.05f);
                    canvas.drawPath(p, paint);
                    Path base = new Path();
                    base.moveTo(left + s * 0.12f, cy + s * 0.05f);
                    base.lineTo(left + s * 0.12f, top + s * 1.0f);
                    base.lineTo(left + s * 0.88f, top + s * 1.0f);
                    base.lineTo(left + s * 0.88f, cy + s * 0.05f);
                    canvas.drawPath(base, paint);
                    break;
                }
                case NavIcon.PLUS: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.10f);
                    canvas.drawLine(cx - size * 0.22f, cy, cx + size * 0.22f, cy, paint);
                    canvas.drawLine(cx, cy - size * 0.22f, cx, cy + size * 0.22f, paint);
                    break;
                }
                case NavIcon.PROFILE: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.085f);
                    canvas.drawCircle(cx, cy - size * 0.16f, size * 0.16f, paint);
                    RectF arc = new RectF(cx - size * 0.32f, cy + size * 0.02f, cx + size * 0.32f, cy + size * 0.62f);
                    canvas.drawArc(arc, 180f, 180f, false, paint);
                    break;
                }
                case NavIcon.PROFILE_FILLED: {
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(cx, cy - size * 0.16f, size * 0.17f, paint);
                    RectF arc = new RectF(cx - size * 0.34f, cy + size * 0.02f, cx + size * 0.34f, cy + size * 0.66f);
                    canvas.drawArc(arc, 180f, 180f, true, paint);
                    break;
                }
                case NavIcon.DOTS: {
                    paint.setStyle(Paint.Style.FILL);
                    float r = size * 0.055f;
                    canvas.drawCircle(cx - size * 0.20f, cy, r, paint);
                    canvas.drawCircle(cx, cy, r, paint);
                    canvas.drawCircle(cx + size * 0.20f, cy, r, paint);
                    break;
                }
                case NavIcon.ARROW_UP: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.09f);
                    canvas.drawLine(cx, cy + size * 0.20f, cx, cy - size * 0.20f, paint);
                    Path head = new Path();
                    head.moveTo(cx - size * 0.16f, cy - size * 0.04f);
                    head.lineTo(cx, cy - size * 0.20f);
                    head.lineTo(cx + size * 0.16f, cy - size * 0.04f);
                    canvas.drawPath(head, paint);
                    break;
                }
                case NavIcon.ARROW_DOWN: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.09f);
                    canvas.drawLine(cx, cy - size * 0.20f, cx, cy + size * 0.20f, paint);
                    Path head = new Path();
                    head.moveTo(cx - size * 0.16f, cy + size * 0.04f);
                    head.lineTo(cx, cy + size * 0.20f);
                    head.lineTo(cx + size * 0.16f, cy + size * 0.04f);
                    canvas.drawPath(head, paint);
                    break;
                }
                case NavIcon.WALLET: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.075f);
                    RectF r = new RectF(cx - size * 0.32f, cy - size * 0.22f, cx + size * 0.32f, cy + size * 0.22f);
                    canvas.drawRoundRect(r, size * 0.08f, size * 0.08f, paint);
                    canvas.drawLine(cx + size * 0.05f, cy - size * 0.05f, cx + size * 0.32f, cy - size * 0.05f, paint);
                    canvas.drawLine(cx + size * 0.05f, cy + size * 0.05f, cx + size * 0.32f, cy + size * 0.05f, paint);
                    canvas.drawCircle(cx + size * 0.16f, cy, size * 0.035f, paint);
                    break;
                }
                case NavIcon.CLOSE: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.09f);
                    canvas.drawLine(cx - size * 0.16f, cy - size * 0.16f, cx + size * 0.16f, cy + size * 0.16f, paint);
                    canvas.drawLine(cx + size * 0.16f, cy - size * 0.16f, cx - size * 0.16f, cy + size * 0.16f, paint);
                    break;
                }
                case NavIcon.CHART: {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(size * 0.075f);
                    canvas.drawLine(cx - size * 0.25f, cy + size * 0.25f, cx + size * 0.25f, cy + size * 0.25f, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawRect(cx - size * 0.20f, cy + size * 0.05f, cx - size * 0.10f, cy + size * 0.22f, paint);
                    canvas.drawRect(cx - size * 0.05f, cy - size * 0.15f, cx + size * 0.05f, cy + size * 0.22f, paint);
                    canvas.drawRect(cx + size * 0.10f, cy - size * 0.05f, cx + size * 0.20f, cy + size * 0.22f, paint);
                    break;
                }
            }
        }
    }
}
